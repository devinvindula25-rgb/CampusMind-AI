/**
 * CampusMind AI - Smart Meeting Manager
 * Schedule, manage, and track meetings with live Firestore CRUD.
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Modal,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { BrandColors, BorderRadius, Spacing, Typography, Shadows } from '@/constants/theme';
import { useAuth } from '@/contexts/AuthContext';
import {
  subscribeMeetings,
  createMeeting,
  updateMeeting,
  deleteMeeting,
} from '@/services/firestore';
import type { Meeting } from '@/services/firestoreTypes';

export default function MeetingsScreen() {
  const { user } = useAuth();
  const [meetings, setMeetings] = useState<Meeting[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);

  // Real-time listener
  useEffect(() => {
    if (!user?.uid) { setLoading(false); return; }
    const unsub = subscribeMeetings(user.uid, (data) => {
      setMeetings(data);
      setLoading(false);
    });
    return () => unsub();
  }, [user?.uid]);

  const getTypeConfig = (type: string) => {
    switch (type) {
      case 'in_person': return { label: 'In-Person', icon: 'meeting-room' as const, color: '#3B82F6' };
      case 'virtual': return { label: 'Virtual', icon: 'videocam' as const, color: '#8B5CF6' };
      case 'hybrid': return { label: 'Hybrid', icon: 'devices' as const, color: '#10B981' };
      default: return { label: type, icon: 'event' as const, color: '#64748B' };
    }
  };

  // Group meetings by date
  const today = new Date().toISOString().split('T')[0];
  const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];

  const grouped = {
    today: meetings.filter((m) => m.date === today),
    tomorrow: meetings.filter((m) => m.date === tomorrow),
    later: meetings.filter((m) => m.date > tomorrow),
  };

  const handleDelete = (meeting: Meeting) => {
    Alert.alert('Delete Meeting', `Delete "${meeting.title}"?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => meeting.id && deleteMeeting(meeting.id) },
    ]);
  };

  const handleToggleStatus = async (meeting: Meeting) => {
    if (!meeting.id) return;
    const newStatus = meeting.status === 'scheduled' ? 'completed' : 'scheduled';
    await updateMeeting(meeting.id, { status: newStatus });
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <LinearGradient colors={['#1B2A4A', '#0F172A']} style={styles.header}>
        <View style={styles.headerTop}>
          <View>
            <Text style={styles.headerTitle}>Meetings</Text>
            <Text style={styles.headerSubtitle}>
              {loading ? 'Loading...' : `${meetings.length} meetings`}
            </Text>
          </View>
          <TouchableOpacity style={styles.createButton} onPress={() => setShowCreateModal(true)}>
            <LinearGradient colors={[BrandColors.accent, BrandColors.accentDark]} style={styles.createButtonGradient}>
              <MaterialIcons name="add" size={20} color="#fff" />
              <Text style={styles.createButtonText}>New</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* Quick Stats */}
        <View style={styles.statsRow}>
          <View style={styles.statCard}><Text style={styles.statValue}>{grouped.today.length}</Text><Text style={styles.statLabel}>Today</Text></View>
          <View style={styles.statCard}><Text style={styles.statValue}>{grouped.tomorrow.length}</Text><Text style={styles.statLabel}>Tomorrow</Text></View>
          <View style={styles.statCard}><Text style={styles.statValue}>{meetings.length}</Text><Text style={styles.statLabel}>Total</Text></View>
          <View style={styles.statCard}><Text style={styles.statValue}>{meetings.filter(m => m.status === 'completed').length}</Text><Text style={styles.statLabel}>Done</Text></View>
        </View>
      </LinearGradient>

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={BrandColors.accent} />
          <Text style={styles.loadingText}>Loading meetings...</Text>
        </View>
      ) : (
        <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          <MeetingSection title="Today" meetings={grouped.today} getTypeConfig={getTypeConfig} onDelete={handleDelete} onToggle={handleToggleStatus} />
          <MeetingSection title="Tomorrow" meetings={grouped.tomorrow} getTypeConfig={getTypeConfig} onDelete={handleDelete} onToggle={handleToggleStatus} />
          <MeetingSection title="Later This Week" meetings={grouped.later} getTypeConfig={getTypeConfig} onDelete={handleDelete} onToggle={handleToggleStatus} />

          {meetings.length === 0 && (
            <View style={styles.emptyState}>
              <MaterialIcons name="event-available" size={64} color="#CBD5E1" />
              <Text style={styles.emptyTitle}>No meetings scheduled</Text>
              <Text style={styles.emptySubtitle}>Tap "New" to create your first meeting</Text>
            </View>
          )}
          <View style={{ height: Spacing['3xl'] }} />
        </ScrollView>
      )}

      {/* Create Meeting Modal */}
      <CreateMeetingModal
        visible={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        userId={user?.uid || ''}
      />
    </View>
  );
}

function MeetingSection({ title, meetings, getTypeConfig, onDelete, onToggle }: {
  title: string;
  meetings: Meeting[];
  getTypeConfig: (type: string) => { label: string; icon: keyof typeof MaterialIcons.glyphMap; color: string };
  onDelete: (m: Meeting) => void;
  onToggle: (m: Meeting) => void;
}) {
  if (meetings.length === 0) return null;

  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {meetings.map((meeting) => {
        const typeConfig = getTypeConfig(meeting.type);
        return (
          <TouchableOpacity
            key={meeting.id}
            style={[styles.meetingCard, meeting.status === 'completed' && styles.meetingDone]}
            activeOpacity={0.7}
            onLongPress={() => onDelete(meeting)}
          >
            <View style={[styles.meetingStripe, { backgroundColor: typeConfig.color }]} />
            <View style={styles.meetingBody}>
              <View style={styles.meetingHeader}>
                <Text style={[styles.meetingTitle, meeting.status === 'completed' && styles.meetingTitleDone]}>
                  {meeting.title}
                </Text>
                <View style={{ flexDirection: 'row', gap: 6 }}>
                  <View style={[styles.typeBadge, { backgroundColor: typeConfig.color + '18' }]}>
                    <MaterialIcons name={typeConfig.icon} size={12} color={typeConfig.color} />
                    <Text style={[styles.typeBadgeText, { color: typeConfig.color }]}>{typeConfig.label}</Text>
                  </View>
                  <TouchableOpacity onPress={() => onToggle(meeting)}>
                    <MaterialIcons
                      name={meeting.status === 'completed' ? 'check-circle' : 'radio-button-unchecked'}
                      size={20}
                      color={meeting.status === 'completed' ? BrandColors.success : '#CBD5E1'}
                    />
                  </TouchableOpacity>
                </View>
              </View>

              <View style={styles.meetingDetails}>
                <View style={styles.detailRow}>
                  <MaterialIcons name="schedule" size={16} color="#64748B" />
                  <Text style={styles.detailText}>{meeting.startTime} – {meeting.endTime}</Text>
                </View>
                {meeting.room && (
                  <View style={styles.detailRow}>
                    <MaterialIcons name="meeting-room" size={16} color="#64748B" />
                    <Text style={styles.detailText}>{meeting.room}</Text>
                  </View>
                )}
                {meeting.teamsLink && (
                  <TouchableOpacity style={styles.joinButton}>
                    <MaterialIcons name="videocam" size={14} color={BrandColors.accent} />
                    <Text style={styles.joinButtonText}>Join Meeting</Text>
                  </TouchableOpacity>
                )}
              </View>

              <View style={styles.attendeesRow}>
                <MaterialIcons name="people" size={14} color="#94A3B8" />
                <Text style={styles.attendeesText}>{meeting.attendees.join(', ')}</Text>
                <TouchableOpacity onPress={() => onDelete(meeting)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                  <MaterialIcons name="delete-outline" size={16} color="#CBD5E1" />
                </TouchableOpacity>
              </View>
            </View>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

function CreateMeetingModal({ visible, onClose, userId }: { visible: boolean; onClose: () => void; userId: string }) {
  const [title, setTitle] = useState('');
  const [meetingType, setMeetingType] = useState<Meeting['type']>('in_person');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [startTime, setStartTime] = useState('09:00');
  const [endTime, setEndTime] = useState('10:00');
  const [room, setRoom] = useState('');
  const [teamsLink, setTeamsLink] = useState('');
  const [attendees, setAttendees] = useState('');
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!title.trim()) { Alert.alert('Missing Title', 'Please enter a meeting title.'); return; }
    setSaving(true);
    await createMeeting(userId, {
      title: title.trim(),
      date,
      startTime,
      endTime,
      type: meetingType,
      room: room.trim() || undefined,
      teamsLink: teamsLink.trim() || undefined,
      attendees: attendees.split(',').map((a) => a.trim()).filter(Boolean),
      attendeeIds: [],
      status: 'scheduled',
    });
    setSaving(false);
    setTitle(''); setRoom(''); setTeamsLink(''); setAttendees('');
    onClose();
  };

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>New Meeting</Text>
            <TouchableOpacity onPress={onClose}><MaterialIcons name="close" size={24} color="#64748B" /></TouchableOpacity>
          </View>

          <ScrollView style={styles.modalScroll}>
            <Text style={styles.fieldLabel}>Meeting Title</Text>
            <TextInput style={styles.fieldInput} placeholder="e.g., Faculty Board Meeting" placeholderTextColor="#94A3B8" value={title} onChangeText={setTitle} />

            <Text style={styles.fieldLabel}>Meeting Type</Text>
            <View style={styles.typeSelector}>
              {([
                { value: 'in_person' as const, label: 'In-Person', icon: 'meeting-room' as const },
                { value: 'virtual' as const, label: 'Virtual', icon: 'videocam' as const },
                { value: 'hybrid' as const, label: 'Hybrid', icon: 'devices' as const },
              ]).map((opt) => (
                <TouchableOpacity key={opt.value} style={[styles.typeOption, meetingType === opt.value && styles.typeOptionActive]} onPress={() => setMeetingType(opt.value)}>
                  <MaterialIcons name={opt.icon} size={18} color={meetingType === opt.value ? BrandColors.accent : '#94A3B8'} />
                  <Text style={[styles.typeOptionText, meetingType === opt.value && styles.typeOptionTextActive]}>{opt.label}</Text>
                </TouchableOpacity>
              ))}
            </View>

            <Text style={styles.fieldLabel}>Date (YYYY-MM-DD)</Text>
            <TextInput style={styles.fieldInput} placeholder="2026-08-25" placeholderTextColor="#94A3B8" value={date} onChangeText={setDate} />

            <View style={styles.dateTimeRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.fieldLabel}>Start Time</Text>
                <TextInput style={styles.fieldInput} placeholder="09:00" placeholderTextColor="#94A3B8" value={startTime} onChangeText={setStartTime} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.fieldLabel}>End Time</Text>
                <TextInput style={styles.fieldInput} placeholder="10:00" placeholderTextColor="#94A3B8" value={endTime} onChangeText={setEndTime} />
              </View>
            </View>

            {meetingType !== 'virtual' && (
              <>
                <Text style={styles.fieldLabel}>Room / Location</Text>
                <TextInput style={styles.fieldInput} placeholder="e.g., Room 204" placeholderTextColor="#94A3B8" value={room} onChangeText={setRoom} />
              </>
            )}

            {meetingType !== 'in_person' && (
              <>
                <Text style={styles.fieldLabel}>Meeting Link</Text>
                <TextInput style={styles.fieldInput} placeholder="Paste Teams/Zoom link..." placeholderTextColor="#94A3B8" value={teamsLink} onChangeText={setTeamsLink} />
              </>
            )}

            <Text style={styles.fieldLabel}>Attendees (comma-separated)</Text>
            <TextInput style={styles.fieldInput} placeholder="Dr. Patel, Prof. Williams" placeholderTextColor="#94A3B8" value={attendees} onChangeText={setAttendees} />

            <TouchableOpacity style={styles.createMeetingButton} activeOpacity={0.8} onPress={handleSave} disabled={saving}>
              <LinearGradient colors={[BrandColors.accent, BrandColors.accentDark]} style={styles.createMeetingGradient}>
                <MaterialIcons name="check" size={20} color="#fff" />
                <Text style={styles.createMeetingText}>{saving ? 'Saving...' : 'Create Meeting'}</Text>
              </LinearGradient>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  header: {
    paddingTop: 56, paddingHorizontal: Spacing.xl, paddingBottom: Spacing.xl,
    borderBottomLeftRadius: BorderRadius['2xl'], borderBottomRightRadius: BorderRadius['2xl'],
  },
  headerTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: Spacing.lg },
  headerTitle: { fontSize: Typography.sizes['2xl'], fontWeight: Typography.weights.bold, color: '#fff' },
  headerSubtitle: { fontSize: Typography.sizes.sm, color: '#94A3B8', marginTop: 2 },
  createButton: { borderRadius: BorderRadius.full, overflow: 'hidden' },
  createButtonGradient: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: Spacing.base, paddingVertical: Spacing.sm, gap: 4 },
  createButtonText: { fontSize: Typography.sizes.sm, fontWeight: Typography.weights.bold, color: '#fff' },
  statsRow: { flexDirection: 'row', gap: Spacing.sm },
  statCard: { flex: 1, backgroundColor: 'rgba(255,255,255,0.08)', borderRadius: BorderRadius.lg, padding: Spacing.md, alignItems: 'center' },
  statValue: { fontSize: Typography.sizes.lg, fontWeight: Typography.weights.extrabold, color: '#fff' },
  statLabel: { fontSize: 10, color: '#94A3B8', marginTop: 2 },

  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: Spacing.md },
  loadingText: { fontSize: Typography.sizes.sm, color: '#94A3B8' },
  emptyState: { alignItems: 'center', paddingTop: Spacing['5xl'] },
  emptyTitle: { fontSize: Typography.sizes.lg, fontWeight: Typography.weights.bold, color: '#334155', marginTop: Spacing.base },
  emptySubtitle: { fontSize: Typography.sizes.sm, color: '#94A3B8', marginTop: 4 },

  scroll: { flex: 1 },
  scrollContent: { padding: Spacing.xl },
  section: { marginBottom: Spacing.xl },
  sectionTitle: { fontSize: Typography.sizes.lg, fontWeight: Typography.weights.bold, color: '#1A1A2E', marginBottom: Spacing.md },

  meetingCard: { flexDirection: 'row', backgroundColor: '#fff', borderRadius: BorderRadius.lg, marginBottom: Spacing.md, overflow: 'hidden', ...Shadows.sm },
  meetingDone: { opacity: 0.6 },
  meetingStripe: { width: 4 },
  meetingBody: { flex: 1, padding: Spacing.base },
  meetingHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: Spacing.sm },
  meetingTitle: { flex: 1, fontSize: Typography.sizes.md, fontWeight: Typography.weights.bold, color: '#1A1A2E', marginRight: Spacing.sm },
  meetingTitleDone: { textDecorationLine: 'line-through', color: '#94A3B8' },
  typeBadge: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, paddingVertical: 3, borderRadius: BorderRadius.sm, gap: 4 },
  typeBadgeText: { fontSize: 10, fontWeight: Typography.weights.bold },
  meetingDetails: { gap: 6, marginBottom: Spacing.sm },
  detailRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  detailText: { fontSize: Typography.sizes.sm, color: '#64748B' },
  joinButton: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: BrandColors.accent + '12', alignSelf: 'flex-start', paddingHorizontal: Spacing.md, paddingVertical: 4, borderRadius: BorderRadius.sm },
  joinButtonText: { fontSize: Typography.sizes.xs, color: BrandColors.accent, fontWeight: Typography.weights.bold },
  attendeesRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  attendeesText: { fontSize: Typography.sizes.xs, color: '#94A3B8', flex: 1 },

  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: '#fff', borderTopLeftRadius: BorderRadius['2xl'], borderTopRightRadius: BorderRadius['2xl'], maxHeight: '85%', paddingBottom: Spacing['3xl'] },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: Spacing.xl, paddingTop: Spacing.xl, paddingBottom: Spacing.md, borderBottomWidth: 1, borderBottomColor: '#F1F5F9' },
  modalTitle: { fontSize: Typography.sizes.xl, fontWeight: Typography.weights.bold, color: '#1A1A2E' },
  modalScroll: { paddingHorizontal: Spacing.xl, paddingTop: Spacing.lg },
  fieldLabel: { fontSize: Typography.sizes.sm, fontWeight: Typography.weights.semibold, color: '#334155', marginBottom: Spacing.sm, marginTop: Spacing.md },
  fieldInput: { backgroundColor: '#F8FAFC', borderRadius: BorderRadius.md, paddingHorizontal: Spacing.base, paddingVertical: Spacing.md, fontSize: Typography.sizes.md, color: '#1A1A2E', borderWidth: 1, borderColor: '#E2E8F0' },
  dateTimeRow: { flexDirection: 'row', gap: Spacing.sm },
  typeSelector: { flexDirection: 'row', gap: Spacing.sm },
  typeOption: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: Spacing.md, borderRadius: BorderRadius.md, gap: 6, backgroundColor: '#F8FAFC', borderWidth: 1.5, borderColor: '#E2E8F0' },
  typeOptionActive: { borderColor: BrandColors.accent, backgroundColor: BrandColors.accent + '08' },
  typeOptionText: { fontSize: Typography.sizes.sm, color: '#94A3B8', fontWeight: Typography.weights.medium },
  typeOptionTextActive: { color: BrandColors.accent, fontWeight: Typography.weights.bold },
  createMeetingButton: { borderRadius: BorderRadius.lg, overflow: 'hidden', marginTop: Spacing.xl },
  createMeetingGradient: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', paddingVertical: Spacing.base, gap: Spacing.sm },
  createMeetingText: { fontSize: Typography.sizes.md, fontWeight: Typography.weights.bold, color: '#fff' },
});
