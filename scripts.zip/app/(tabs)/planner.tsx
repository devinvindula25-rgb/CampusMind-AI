/**
 * CampusMind AI - Intelligent Academic Planner
 * Interactive daily/weekly calendar with AI-suggested time blocking.
 * Dynamic month/year navigation with real date calculations.
 */

import React, { useState, useMemo, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Modal,
  TextInput,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { BrandColors, BorderRadius, Spacing, Typography, Shadows } from '@/constants/theme';
import { useSettings } from '@/contexts/SettingsContext';
import { useAuth } from '@/contexts/AuthContext';
import { subscribeSchedules, createSchedule, deleteSchedule } from '@/services/firestore';
import type { ScheduleItem } from '@/services/firestoreTypes';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

const ACTIVITY_TYPES = {
  lecture_prep: { label: 'Lecture Prep', color: '#3B82F6', icon: 'menu-book' as const },
  research_writing: { label: 'Research Writing', color: '#8B5CF6', icon: 'edit-note' as const },
  student_consultations: { label: 'Student Hours', color: '#10B981', icon: 'people' as const },
  assessment_review: { label: 'Assessment', color: '#EF4444', icon: 'grading' as const },
  meetings: { label: 'Meetings', color: '#F59E0B', icon: 'groups' as const },
  admin: { label: 'Admin', color: '#64748B', icon: 'business-center' as const },
  break: { label: 'Break', color: '#06B6D4', icon: 'coffee' as const },
};

// Mock data removed — data now comes from Firestore via subscribeSchedules

const HOURS = Array.from({ length: 12 }, (_, i) => i + 7); // 7 AM to 6 PM
const DAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

export default function PlannerScreen() {
  const { resolvedTheme } = useSettings();
  const { user } = useAuth();
  const isDark = resolvedTheme === 'dark';

  const today = new Date();
  const [currentYear, setCurrentYear] = useState(today.getFullYear());
  const [currentMonth, setCurrentMonth] = useState(today.getMonth());
  const [selectedDate, setSelectedDate] = useState(today.getDate());
  const [viewMode, setViewMode] = useState<'day' | 'week'>('day');
  const [schedule, setSchedule] = useState<ScheduleItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);

  // Build date string for the selected date
  const selectedDateStr = useMemo(() => {
    const m = String(currentMonth + 1).padStart(2, '0');
    const d = String(selectedDate).padStart(2, '0');
    return `${currentYear}-${m}-${d}`;
  }, [currentYear, currentMonth, selectedDate]);

  // Real-time listener — re-subscribes when the selected date changes
  useEffect(() => {
    if (!user?.uid) { setLoading(false); return; }
    setLoading(true);
    const unsub = subscribeSchedules(user.uid, selectedDateStr, (items) => {
      setSchedule(items);
      setLoading(false);
    });
    return () => unsub();
  }, [user?.uid, selectedDateStr]);

  const handleDeleteEvent = (item: ScheduleItem) => {
    Alert.alert('Delete Event', `Delete "${item.title}"?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => item.id && deleteSchedule(item.id) },
    ]);
  };

  // Calculate week containing the selected date
  const weekDays = useMemo(() => {
    const selected = new Date(currentYear, currentMonth, selectedDate);
    const dayOfWeek = selected.getDay(); // 0=Sun
    const monday = new Date(selected);
    monday.setDate(selected.getDate() - ((dayOfWeek + 6) % 7)); // Go to Monday

    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(monday);
      d.setDate(monday.getDate() + i);
      return {
        date: d.getDate(),
        day: DAY_NAMES[d.getDay()],
        month: d.getMonth(),
        year: d.getFullYear(),
        isToday: d.toDateString() === today.toDateString(),
        isSelected: d.getDate() === selectedDate && d.getMonth() === currentMonth && d.getFullYear() === currentYear,
        fullDate: d,
      };
    });
  }, [currentYear, currentMonth, selectedDate]);

  // Get week number
  const getWeekNumber = (date: Date) => {
    const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
    d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    return Math.ceil(((d.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
  };

  const navigateMonth = (direction: number) => {
    let newMonth = currentMonth + direction;
    let newYear = currentYear;
    if (newMonth < 0) { newMonth = 11; newYear--; }
    if (newMonth > 11) { newMonth = 0; newYear++; }
    setCurrentMonth(newMonth);
    setCurrentYear(newYear);
    setSelectedDate(1);
  };

  const goToToday = () => {
    setCurrentYear(today.getFullYear());
    setCurrentMonth(today.getMonth());
    setSelectedDate(today.getDate());
  };

  const getTimePosition = (time: string) => {
    const [h, m] = time.split(':').map(Number);
    return ((h - 7) * 60 + m);
  };

  const getBlockHeight = (start: string, end: string) => {
    return getTimePosition(end) - getTimePosition(start);
  };

  const selectedFullDate = new Date(currentYear, currentMonth, selectedDate);
  const weekNum = getWeekNumber(selectedFullDate);

  return (
    <View style={[styles.container, isDark && styles.containerDark]}>
      {/* Header */}
      <LinearGradient colors={isDark ? ['#1E293B', '#0F172A'] : ['#1B2A4A', '#0F172A']} style={styles.header}>
        <View style={styles.headerTop}>
          <View style={styles.headerLeft}>
            <Text style={styles.headerTitle}>Academic Planner</Text>
            {/* Month/Year Navigation */}
            <View style={styles.monthNav}>
              <TouchableOpacity onPress={() => navigateMonth(-1)} style={styles.navArrow}>
                <MaterialIcons name="chevron-left" size={24} color="#94A3B8" />
              </TouchableOpacity>
              <TouchableOpacity onPress={goToToday}>
                <Text style={styles.monthYearText}>
                  {MONTH_NAMES[currentMonth]} {currentYear}
                </Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => navigateMonth(1)} style={styles.navArrow}>
                <MaterialIcons name="chevron-right" size={24} color="#94A3B8" />
              </TouchableOpacity>
              <View style={styles.weekBadge}>
                <Text style={styles.weekBadgeText}>W{weekNum}</Text>
              </View>
            </View>
          </View>
          <View style={styles.headerRight}>
            <TouchableOpacity style={styles.todayButton} onPress={goToToday}>
              <MaterialIcons name="today" size={16} color={BrandColors.accent} />
              <Text style={styles.todayButtonText}>Today</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.aiGenerateButton}>
              <LinearGradient
                colors={[BrandColors.secondary, BrandColors.accent]}
                style={styles.aiGenerateGradient}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
              >
                <MaterialIcons name="auto-awesome" size={16} color="#fff" />
                <Text style={styles.aiGenerateText}>AI Plan</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        </View>

        {/* Day Selector */}
        <View style={styles.daySelector}>
          {weekDays.map((day, index) => (
            <TouchableOpacity
              key={index}
              style={[
                styles.dayItem,
                day.isSelected && styles.dayItemActive,
                day.isToday && !day.isSelected && styles.dayItemToday,
              ]}
              onPress={() => {
                setSelectedDate(day.date);
                setCurrentMonth(day.month);
                setCurrentYear(day.year);
              }}
            >
              <Text style={[styles.dayName, day.isSelected && styles.dayNameActive]}>{day.day}</Text>
              <Text style={[styles.dayDate, day.isSelected && styles.dayDateActive]}>{day.date}</Text>
              {day.isToday && <View style={[styles.todayDot, day.isSelected && styles.todayDotActive]} />}
            </TouchableOpacity>
          ))}
        </View>

        {/* View Toggle */}
        <View style={styles.viewToggle}>
          <TouchableOpacity
            style={[styles.toggleButton, viewMode === 'day' && styles.toggleButtonActive]}
            onPress={() => setViewMode('day')}
          >
            <MaterialIcons name="view-day" size={14} color={viewMode === 'day' ? '#fff' : '#94A3B8'} />
            <Text style={[styles.toggleText, viewMode === 'day' && styles.toggleTextActive]}>Day</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.toggleButton, viewMode === 'week' && styles.toggleButtonActive]}
            onPress={() => setViewMode('week')}
          >
            <MaterialIcons name="view-week" size={14} color={viewMode === 'week' ? '#fff' : '#94A3B8'} />
            <Text style={[styles.toggleText, viewMode === 'week' && styles.toggleTextActive]}>Week</Text>
          </TouchableOpacity>
        </View>
      </LinearGradient>

      {/* Activity Legend */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.legendScroll} contentContainerStyle={styles.legendContent}>
        {Object.entries(ACTIVITY_TYPES).map(([key, val]) => (
          <View key={key} style={[styles.legendItem, isDark && styles.legendItemDark]}>
            <View style={[styles.legendDot, { backgroundColor: val.color }]} />
            <Text style={[styles.legendLabel, isDark && styles.legendLabelDark]}>{val.label}</Text>
          </View>
        ))}
      </ScrollView>

      {/* Date Info Bar */}
      <View style={[styles.dateInfoBar, isDark && styles.dateInfoBarDark]}>
        <MaterialIcons name="event" size={16} color={BrandColors.accent} />
        <Text style={[styles.dateInfoText, isDark && styles.dateInfoTextDark]}>
          {DAY_NAMES[selectedFullDate.getDay()]}, {selectedDate} {MONTH_NAMES[currentMonth]} {currentYear}
        </Text>
        <View style={styles.dateInfoBadge}>
          <Text style={styles.dateInfoBadgeText}>{loading ? '...' : `${schedule.length} events`}</Text>
        </View>
      </View>

      {/* Timeline */}
      {loading ? (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <ActivityIndicator size="large" color={BrandColors.accent} />
        </View>
      ) : (
        <ScrollView style={styles.timelineScroll} showsVerticalScrollIndicator={false}>
          <View style={styles.timeline}>
            {/* Hour Lines */}
            {HOURS.map((hour) => (
              <View key={hour} style={[styles.hourRow, { top: (hour - 7) * 60 }]}>
                <Text style={[styles.hourLabel, isDark && styles.hourLabelDark]}>
                  {hour > 12 ? `${hour - 12} PM` : hour === 12 ? '12 PM' : `${hour} AM`}
                </Text>
                <View style={[styles.hourLine, isDark && styles.hourLineDark]} />
              </View>
            ))}

            {/* Schedule Blocks from Firestore */}
            {schedule.map((item) => {
              const type = ACTIVITY_TYPES[item.type as keyof typeof ACTIVITY_TYPES] || { color: '#64748B', icon: 'event' as const, label: item.type };
              const top = getTimePosition(item.startTime);
              const height = getBlockHeight(item.startTime, item.endTime);

              return (
                <TouchableOpacity
                  key={item.id}
                  style={[
                    styles.scheduleBlock,
                    {
                      top: top,
                      height: Math.max(height - 2, 30),
                      backgroundColor: type.color + '18',
                      borderLeftColor: type.color,
                    },
                    isDark && { backgroundColor: type.color + '25' },
                  ]}
                  activeOpacity={0.7}
                  onLongPress={() => handleDeleteEvent(item)}
                >
                  <View style={styles.blockHeader}>
                    <MaterialIcons name={type.icon} size={14} color={type.color} />
                    <Text style={[styles.blockTime, { color: type.color }]}>
                      {item.startTime} – {item.endTime}
                    </Text>
                    {item.isAI && (
                      <View style={[styles.aiBadge, { backgroundColor: type.color + '25' }]}>
                        <MaterialIcons name="auto-awesome" size={10} color={type.color} />
                        <Text style={[styles.aiBadgeText, { color: type.color }]}>AI</Text>
                      </View>
                    )}
                  </View>
                  <Text style={[styles.blockTitle, isDark && styles.blockTitleDark]} numberOfLines={1}>{item.title}</Text>
                </TouchableOpacity>
              );
            })}

            {schedule.length === 0 && (
              <View style={{ position: 'absolute', top: 120, left: 0, right: 0, alignItems: 'center' }}>
                <MaterialIcons name="event-available" size={48} color="#CBD5E1" />
                <Text style={{ color: '#94A3B8', marginTop: 8, fontSize: 14 }}>No events for this day</Text>
                <TouchableOpacity onPress={() => setShowCreateModal(true)} style={{ marginTop: 12, backgroundColor: BrandColors.accent, paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20 }}>
                  <Text style={{ color: '#fff', fontWeight: '700', fontSize: 13 }}>+ Add Event</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
          <View style={{ height: Spacing['3xl'] }} />
        </ScrollView>
      )}

      {/* Add Event FAB */}
      <TouchableOpacity
        style={{ position: 'absolute', bottom: 24, right: 24, width: 52, height: 52, borderRadius: 26, overflow: 'hidden' }}
        onPress={() => setShowCreateModal(true)}
      >
        <LinearGradient colors={[BrandColors.accent, BrandColors.accentDark]} style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <MaterialIcons name="add" size={28} color="#fff" />
        </LinearGradient>
      </TouchableOpacity>

      {/* Create Event Modal */}
      <CreateEventModal
        visible={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        userId={user?.uid || ''}
        date={selectedDateStr}
      />
    </View>
  );
}

// ─── Create Event Modal ───────────────────────────────────────

function CreateEventModal({ visible, onClose, userId, date }: { visible: boolean; onClose: () => void; userId: string; date: string }) {
  const [title, setTitle] = useState('');
  const [startTime, setStartTime] = useState('09:00');
  const [endTime, setEndTime] = useState('10:00');
  const [type, setType] = useState<ScheduleItem['type']>('lecture_prep');
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!title.trim()) { Alert.alert('Missing', 'Enter a title'); return; }
    setSaving(true);
    await createSchedule(userId, { date, startTime, endTime, title: title.trim(), type, isAI: false });
    setSaving(false);
    setTitle('');
    onClose();
  };

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' }}>
        <View style={{ backgroundColor: '#fff', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, maxHeight: '80%' }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
            <Text style={{ fontSize: 20, fontWeight: '800', color: '#1A1A2E' }}>New Event — {date}</Text>
            <TouchableOpacity onPress={onClose}><MaterialIcons name="close" size={24} color="#64748B" /></TouchableOpacity>
          </View>

          <Text style={{ fontSize: 13, fontWeight: '600', color: '#64748B', marginBottom: 6 }}>Title</Text>
          <TextInput style={{ backgroundColor: '#F8FAFC', borderRadius: 10, padding: 12, fontSize: 15, borderWidth: 1, borderColor: '#E2E8F0', marginBottom: 12 }} value={title} onChangeText={setTitle} placeholder="Event title..." placeholderTextColor="#94A3B8" />

          <View style={{ flexDirection: 'row', gap: 10, marginBottom: 12 }}>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 13, fontWeight: '600', color: '#64748B', marginBottom: 6 }}>Start</Text>
              <TextInput style={{ backgroundColor: '#F8FAFC', borderRadius: 10, padding: 12, fontSize: 15, borderWidth: 1, borderColor: '#E2E8F0' }} value={startTime} onChangeText={setStartTime} placeholder="09:00" placeholderTextColor="#94A3B8" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 13, fontWeight: '600', color: '#64748B', marginBottom: 6 }}>End</Text>
              <TextInput style={{ backgroundColor: '#F8FAFC', borderRadius: 10, padding: 12, fontSize: 15, borderWidth: 1, borderColor: '#E2E8F0' }} value={endTime} onChangeText={setEndTime} placeholder="10:00" placeholderTextColor="#94A3B8" />
            </View>
          </View>

          <Text style={{ fontSize: 13, fontWeight: '600', color: '#64748B', marginBottom: 6 }}>Type</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 16 }}>
            {Object.entries(ACTIVITY_TYPES).map(([key, val]) => (
              <TouchableOpacity key={key} onPress={() => setType(key as any)} style={{ paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, backgroundColor: type === key ? val.color : '#F1F5F9', marginRight: 8 }}>
                <Text style={{ color: type === key ? '#fff' : '#64748B', fontWeight: '600', fontSize: 13 }}>{val.label}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          <TouchableOpacity onPress={handleSave} disabled={saving} style={{ borderRadius: 12, overflow: 'hidden' }}>
            <LinearGradient colors={[BrandColors.accent, BrandColors.accentDark]} style={{ paddingVertical: 14, alignItems: 'center' }}>
              <Text style={{ color: '#fff', fontWeight: '800', fontSize: 15 }}>{saving ? 'Saving...' : 'Add Event'}</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  containerDark: { backgroundColor: '#0F172A' },
  header: {
    paddingTop: 56,
    paddingHorizontal: Spacing.xl,
    paddingBottom: Spacing.base,
    borderBottomLeftRadius: BorderRadius['2xl'],
    borderBottomRightRadius: BorderRadius['2xl'],
  },
  headerTop: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: Spacing.lg,
  },
  headerLeft: {},
  headerRight: { alignItems: 'flex-end', gap: Spacing.sm },
  headerTitle: { fontSize: Typography.sizes['2xl'], fontWeight: Typography.weights.bold, color: '#fff' },

  // Month/Year Navigation
  monthNav: {
    flexDirection: 'row', alignItems: 'center', marginTop: 6, gap: 2,
  },
  navArrow: {
    width: 28, height: 28, borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.08)',
    justifyContent: 'center', alignItems: 'center',
  },
  monthYearText: {
    fontSize: Typography.sizes.base, fontWeight: Typography.weights.semibold, color: '#E2E8F0',
    paddingHorizontal: Spacing.sm,
  },
  weekBadge: {
    backgroundColor: BrandColors.accent + '25',
    borderRadius: BorderRadius.sm, paddingHorizontal: 8, paddingVertical: 2, marginLeft: 6,
  },
  weekBadgeText: { fontSize: 11, fontWeight: '700', color: BrandColors.accent },

  // Today button
  todayButton: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: 10, paddingVertical: 5,
    borderRadius: BorderRadius.full, backgroundColor: 'rgba(255,255,255,0.08)',
  },
  todayButtonText: { fontSize: 12, fontWeight: '600', color: BrandColors.accent },

  aiGenerateButton: { borderRadius: BorderRadius.full, overflow: 'hidden' },
  aiGenerateGradient: {
    flexDirection: 'row', alignItems: 'center', paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.sm, gap: 6,
  },
  aiGenerateText: { fontSize: Typography.sizes.sm, fontWeight: Typography.weights.bold, color: '#fff' },

  // Day Selector
  daySelector: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: Spacing.md },
  dayItem: {
    alignItems: 'center', paddingVertical: Spacing.sm, paddingHorizontal: Spacing.md,
    borderRadius: BorderRadius.lg, gap: 2, minWidth: 40,
  },
  dayItemActive: { backgroundColor: BrandColors.accent },
  dayItemToday: { backgroundColor: 'rgba(255,255,255,0.06)' },
  dayName: { fontSize: Typography.sizes.xs, color: '#94A3B8', fontWeight: Typography.weights.medium },
  dayNameActive: { color: '#fff' },
  dayDate: { fontSize: Typography.sizes.lg, fontWeight: Typography.weights.bold, color: '#CBD5E1' },
  dayDateActive: { color: '#fff' },
  todayDot: {
    width: 4, height: 4, borderRadius: 2, backgroundColor: BrandColors.accent, marginTop: 2,
  },
  todayDotActive: { backgroundColor: '#fff' },

  // View Toggle
  viewToggle: {
    flexDirection: 'row', backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: BorderRadius.full, padding: 3,
  },
  toggleButton: {
    flex: 1, flexDirection: 'row', paddingVertical: Spacing.sm, borderRadius: BorderRadius.full,
    alignItems: 'center', justifyContent: 'center', gap: 4,
  },
  toggleButtonActive: { backgroundColor: 'rgba(255,255,255,0.15)' },
  toggleText: { fontSize: Typography.sizes.sm, color: '#94A3B8', fontWeight: Typography.weights.medium },
  toggleTextActive: { color: '#fff', fontWeight: Typography.weights.bold },

  // Date Info Bar
  dateInfoBar: {
    flexDirection: 'row', alignItems: 'center', paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.sm, gap: Spacing.sm, backgroundColor: '#fff',
    marginHorizontal: Spacing.xl, marginTop: Spacing.md,
    borderRadius: BorderRadius.lg, ...Shadows.sm,
  },
  dateInfoBarDark: { backgroundColor: '#1E293B' },
  dateInfoText: { flex: 1, fontSize: Typography.sizes.sm, fontWeight: Typography.weights.semibold, color: '#334155' },
  dateInfoTextDark: { color: '#E2E8F0' },
  dateInfoBadge: {
    backgroundColor: BrandColors.accent + '15', borderRadius: BorderRadius.full,
    paddingHorizontal: 10, paddingVertical: 3,
  },
  dateInfoBadgeText: { fontSize: 11, fontWeight: '600', color: BrandColors.accent },

  // Legend
  legendScroll: { maxHeight: 40 },
  legendContent: { paddingHorizontal: Spacing.xl, paddingVertical: Spacing.sm, gap: Spacing.base },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  legendItemDark: {},
  legendDot: { width: 8, height: 8, borderRadius: 4 },
  legendLabel: { fontSize: Typography.sizes.xs, color: '#64748B' },
  legendLabelDark: { color: '#94A3B8' },

  // Timeline
  timelineScroll: { flex: 1 },
  timeline: { marginLeft: 56, marginRight: Spacing.xl, height: 12 * 60, position: 'relative' },
  hourRow: { position: 'absolute', left: -56, right: 0, flexDirection: 'row', alignItems: 'flex-start' },
  hourLabel: { width: 48, fontSize: Typography.sizes.xs, color: '#94A3B8', textAlign: 'right', marginRight: Spacing.sm },
  hourLabelDark: { color: '#64748B' },
  hourLine: { flex: 1, height: 1, backgroundColor: '#E2E8F0', marginTop: 7 },
  hourLineDark: { backgroundColor: '#334155' },

  // Schedule Block
  scheduleBlock: {
    position: 'absolute', left: 0, right: 0, borderRadius: BorderRadius.md,
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm,
    borderLeftWidth: 3, justifyContent: 'center',
  },
  blockHeader: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 2 },
  blockTime: { fontSize: 11, fontWeight: Typography.weights.semibold },
  blockTitle: { fontSize: Typography.sizes.sm, fontWeight: Typography.weights.semibold, color: '#1A1A2E' },
  blockTitleDark: { color: '#E2E8F0' },
  aiBadge: {
    flexDirection: 'row', alignItems: 'center', paddingHorizontal: 5, paddingVertical: 1,
    borderRadius: BorderRadius.sm, gap: 2, marginLeft: 'auto',
  },
  aiBadgeText: { fontSize: 9, fontWeight: Typography.weights.bold },
});
