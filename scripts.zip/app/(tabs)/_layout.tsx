/**
 * CampusMind AI - Tab Layout
 * Bottom tab navigation with 5 academic-focused modules.
 * AI is now a floating button, not a tab.
 */

import { Tabs } from 'expo-router';
import React from 'react';
import { View, StyleSheet, Platform } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { BrandColors, BorderRadius, Shadows } from '@/constants/theme';
import { useSettings } from '@/contexts/SettingsContext';

export default function TabLayout() {
  const { settings, resolvedTheme } = useSettings();
  const isDark = resolvedTheme === 'dark';
  const isSidebarMode = settings.navigationMode === 'sidebar';

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: BrandColors.accent,
        tabBarInactiveTintColor: isDark ? '#64748B' : '#94A3B8',
        tabBarStyle: {
          display: isSidebarMode ? 'none' : 'flex',
          backgroundColor: isDark ? '#1E293B' : '#FFFFFF',
          borderTopWidth: 0,
          height: Platform.OS === 'ios' ? 88 : 68,
          paddingBottom: Platform.OS === 'ios' ? 28 : 10,
          paddingTop: 8,
          ...Shadows.lg,
        },
        tabBarLabelStyle: {
          fontSize: 10,
          fontWeight: '600',
          marginTop: 2,
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Dashboard',
          tabBarIcon: ({ color, focused }) => (
            <View style={focused ? styles.activeIconBg : undefined}>
              <MaterialIcons name="dashboard" size={22} color={color} />
            </View>
          ),
        }}
      />
      <Tabs.Screen
        name="planner"
        options={{
          title: 'Planner',
          tabBarIcon: ({ color, focused }) => (
            <View style={focused ? styles.activeIconBg : undefined}>
              <MaterialIcons name="event-note" size={22} color={color} />
            </View>
          ),
        }}
      />
      <Tabs.Screen
        name="research"
        options={{
          title: 'Research',
          tabBarIcon: ({ color, focused }) => (
            <View style={focused ? styles.activeIconBg : undefined}>
              <MaterialIcons name="science" size={22} color={color} />
            </View>
          ),
        }}
      />
      <Tabs.Screen
        name="meetings"
        options={{
          title: 'Meetings',
          tabBarIcon: ({ color, focused }) => (
            <View style={focused ? styles.activeIconBg : undefined}>
              <MaterialIcons name="groups" size={22} color={color} />
            </View>
          ),
        }}
      />
      <Tabs.Screen
        name="burnout"
        options={{
          title: 'Well-being',
          tabBarIcon: ({ color, focused }) => (
            <View style={focused ? styles.activeIconBg : undefined}>
              <MaterialIcons name="favorite" size={22} color={color} />
            </View>
          ),
        }}
      />
      {/* Hidden tabs - AI is now a floating button */}
      <Tabs.Screen name="ai-assistant" options={{ href: null }} />
      <Tabs.Screen name="explore" options={{ href: null }} />
      <Tabs.Screen name="programmes" options={{ href: null }} />
      <Tabs.Screen name="compliance" options={{ href: null }} />
      <Tabs.Screen name="notifications" options={{ href: null }} />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  activeIconBg: {
    backgroundColor: BrandColors.accent + '15',
    borderRadius: BorderRadius.md,
    padding: 5,
  },
});
