/**
 * CampusMind AI - Settings Screen
 * Comprehensive app settings: account, appearance, notifications, accessibility, data, and about.
 */

import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '@/contexts/AuthContext';
import { useSettings } from '@/contexts/SettingsContext';
import { BrandColors, BorderRadius, Spacing, Typography, Shadows, RoleLabels } from '@/constants/theme';

export default function SettingsScreen() {
  const { userProfile, signOut } = useAuth();
  const { settings, resolvedTheme, updateSetting, resetSettings } = useSettings();
  const isDark = resolvedTheme === 'dark';

  const handleResetSettings = () => {
    Alert.alert(
      'Reset Settings',
      'This will restore all settings to their defaults. Are you sure?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Reset', style: 'destructive', onPress: resetSettings },
      ]
    );
  };

  const handleDeleteAccount = () => {
    Alert.alert(
      'Delete Account',
      'This will permanently delete your account and all data. This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Delete', style: 'destructive', onPress: () => {} },
      ]
    );
  };

  return (
    <View style={[styles.container, isDark && { backgroundColor: '#0F172A' }]}>
      {/* Header */}
      <LinearGradient colors={['#1B2A4A', '#0F172A']} style={styles.header}>
        <View style={styles.headerRow}>
          <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
            <MaterialIcons name="arrow-back" size={24} color="#fff" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Settings</Text>
          <View style={{ width: 40 }} />
        </View>
      </LinearGradient>

      <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* ─── Account ──────────────────────────────────── */}
        <SectionHeader title="Account" icon="person" isDark={isDark} />
        <View style={[styles.card, isDark && { backgroundColor: '#1E293B' }]}>
          <View style={styles.profileRow}>
            <LinearGradient
              colors={[BrandColors.accent, BrandColors.secondary]}
              style={styles.profileAvatar}
            >
              <Text style={styles.profileAvatarText}>
                {(userProfile?.name || 'U').charAt(0).toUpperCase()}
              </Text>
            </LinearGradient>
            <View style={styles.profileInfo}>
              <Text style={[styles.profileName, isDark && { color: '#F1F5F9' }]}>{userProfile?.name || 'User'}</Text>
              <Text style={styles.profileEmail}>{userProfile?.email || 'user@university.edu'}</Text>
              <Text style={styles.profileRole}>
                {userProfile?.role ? RoleLabels[userProfile.role] : 'Lecturer'}
              </Text>
            </View>
            <TouchableOpacity>
              <MaterialIcons name="edit" size={20} color={BrandColors.accent} />
            </TouchableOpacity>
          </View>
        </View>

        {/* ─── Appearance ───────────────────────────────── */}
        <SectionHeader title="Appearance" icon="palette" isDark={isDark} />
        <View style={[styles.card, isDark && { backgroundColor: '#1E293B' }]}>
          <SettingRowSelect
            icon="brightness-6"
            label="Theme"
            value={settings.themeMode === 'light' ? 'Light' : settings.themeMode === 'dark' ? 'Dark' : 'System'}
            options={['Light', 'Dark', 'System']}
            onSelect={(v) => updateSetting('themeMode', v.toLowerCase() as any)}
            isDark={isDark}
          />
          <SettingRowSelect
            icon="text-fields"
            label="Font Size"
            value={settings.fontSize.charAt(0).toUpperCase() + settings.fontSize.slice(1)}
            options={['Small', 'Medium', 'Large']}
            onSelect={(v) => updateSetting('fontSize', v.toLowerCase() as any)}
            isDark={isDark}
          />
        </View>

        {/* ─── Accessibility ────────────────────────────── */}
        <SectionHeader title="Accessibility" icon="accessibility" isDark={isDark} />
        <View style={[styles.card, isDark && { backgroundColor: '#1E293B' }]}>
          <SettingRowToggle
            icon="view-sidebar"
            label="Navigation Panel Mode"
            description="Replace gesture navigation with a persistent sidebar panel"
            value={settings.navigationMode === 'sidebar'}
            onToggle={(v) => updateSetting('navigationMode', v ? 'sidebar' : 'tabs')}
            isDark={isDark}
          />
          <SettingRowToggle
            icon="contrast"
            label="High Contrast"
            description="Increase contrast for better readability"
            value={settings.highContrast}
            onToggle={(v) => updateSetting('highContrast', v)}
            isDark={isDark}
          />
        </View>

        {/* ─── Focus & Wellness ─────────────────────────── */}
        <SectionHeader title="Focus & Wellness" icon="self-improvement" isDark={isDark} />
        <View style={[styles.card, isDark && { backgroundColor: '#1E293B' }]}>
          <SettingRowToggle
            icon="center-focus-strong"
            label="Focus Mode"
            description="Full-screen distraction-free mode during deep work"
            value={settings.focusModeEnabled}
            onToggle={(v) => updateSetting('focusModeEnabled', v)}
            isDark={isDark}
          />
          <SettingRowToggle
            icon="timer"
            label="Ergonomic Reminders"
            description="Reminders to stretch and rest eyes (20-20-20 rule)"
            value={settings.ergonomicReminders}
            onToggle={(v) => updateSetting('ergonomicReminders', v)}
            isDark={isDark}
          />
          <SettingRowSelect
            icon="schedule"
            label="Reminder Interval"
            value={`${settings.reminderInterval} min`}
            options={['15 min', '20 min', '30 min', '45 min', '60 min']}
            onSelect={(v) => updateSetting('reminderInterval', parseInt(v))}
            isDark={isDark}
          />
          <SettingRowToggle
            icon="water-drop"
            label="Hydration Reminders"
            description="Periodic reminders to drink water"
            value={settings.hydrationReminders}
            onToggle={(v) => updateSetting('hydrationReminders', v)}
            isDark={isDark}
          />
        </View>

        {/* ─── Notifications ────────────────────────────── */}
        <SectionHeader title="Notifications" icon="notifications" isDark={isDark} />
        <View style={[styles.card, isDark && { backgroundColor: '#1E293B' }]}>
          <SettingRowToggle
            icon="notifications-active"
            label="Push Notifications"
            description="Enable all push notifications"
            value={settings.notificationsEnabled}
            onToggle={(v) => updateSetting('notificationsEnabled', v)}
            isDark={isDark}
          />
          <SettingRowToggle
            icon="event"
            label="Deadline Reminders"
            description="24h before assessment deadlines"
            value={settings.deadlineReminders}
            onToggle={(v) => updateSetting('deadlineReminders', v)}
            isDark={isDark}
          />
          <SettingRowToggle
            icon="favorite"
            label="Burnout Alerts"
            description="Alert when wellness score drops below threshold"
            value={settings.burnoutAlerts}
            onToggle={(v) => updateSetting('burnoutAlerts', v)}
            isDark={isDark}
          />
          <SettingRowToggle
            icon="groups"
            label="Meeting Reminders"
            description="30 minutes before scheduled meetings"
            value={settings.meetingReminders}
            onToggle={(v) => updateSetting('meetingReminders', v)}
            isDark={isDark}
          />
        </View>

        {/* ─── Data & Privacy ───────────────────────────── */}
        <SectionHeader title="Data & Privacy" icon="security" isDark={isDark} />
        <View style={[styles.card, isDark && { backgroundColor: '#1E293B' }]}>
          <SettingRowAction
            icon="download"
            label="Export My Data"
            description="Download all your personal data as JSON"
            onPress={() => Alert.alert('Coming Soon', 'Data export will be available in a future update.')}
            isDark={isDark}
          />
          <SettingRowAction
            icon="delete-sweep"
            label="Clear Local Cache"
            description="Remove cached data from this device"
            onPress={() => Alert.alert('Cache Cleared', 'Local cache has been cleared.')}
            isDark={isDark}
          />
          <SettingRowAction
            icon="restore"
            label="Reset All Settings"
            description="Restore all settings to defaults"
            onPress={handleResetSettings}
            destructive
            isDark={isDark}
          />
        </View>

        {/* ─── About ────────────────────────────────────── */}
        <SectionHeader title="About" icon="info" isDark={isDark} />
        <View style={[styles.card, isDark && { backgroundColor: '#1E293B' }]}>
          <InfoRow label="App Version" value="1.0.0" isDark={isDark} />
          <InfoRow label="Build" value="2026.08.23" isDark={isDark} />
          <InfoRow label="Platform" value="React Native (Expo)" isDark={isDark} />
          <InfoRow label="AI Model" value="Gemini 3.1 Pro" isDark={isDark} />
          <SettingRowAction
            icon="policy"
            label="Privacy Policy"
            onPress={() => {}}
            isDark={isDark}
          />
          <SettingRowAction
            icon="gavel"
            label="Terms of Service"
            onPress={() => {}}
            isDark={isDark}
          />
        </View>

        {/* Danger Zone */}
        <View style={styles.dangerZone}>
          <TouchableOpacity style={styles.signOutButton} onPress={signOut}>
            <MaterialIcons name="logout" size={20} color={BrandColors.error} />
            <Text style={styles.signOutText}>Sign Out</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.deleteButton} onPress={handleDeleteAccount}>
            <MaterialIcons name="delete-forever" size={20} color="#fff" />
            <Text style={styles.deleteText}>Delete Account</Text>
          </TouchableOpacity>
        </View>

        <View style={{ height: Spacing['3xl'] }} />
      </ScrollView>
    </View>
  );
}

// ─── Sub-components ──────────────────────────────────────────

function SectionHeader({ title, icon, isDark }: { title: string; icon: keyof typeof MaterialIcons.glyphMap; isDark: boolean }) {
  return (
    <View style={styles.sectionHeader}>
      <MaterialIcons name={icon} size={18} color={isDark ? '#94A3B8' : '#64748B'} />
      <Text style={[styles.sectionTitle, isDark && { color: '#94A3B8' }]}>{title}</Text>
    </View>
  );
}

function SettingRowToggle({ icon, label, description, value, onToggle, isDark }: {
  icon: keyof typeof MaterialIcons.glyphMap;
  label: string;
  description?: string;
  value: boolean;
  onToggle: (v: boolean) => void;
  isDark: boolean;
}) {
  return (
    <View style={[styles.settingRow, isDark && { borderBottomColor: '#334155' }]}>
      <View style={styles.settingIconContainer}>
        <MaterialIcons name={icon} size={20} color={BrandColors.accent} />
      </View>
      <View style={styles.settingContent}>
        <Text style={[styles.settingLabel, isDark && { color: '#F1F5F9' }]}>{label}</Text>
        {description && <Text style={[styles.settingDescription, isDark && { color: '#94A3B8' }]}>{description}</Text>}
      </View>
      <Switch
        value={value}
        onValueChange={onToggle}
        trackColor={{ false: isDark ? '#475569' : '#E2E8F0', true: BrandColors.accent + '60' }}
        thumbColor={value ? BrandColors.accent : (isDark ? '#94A3B8' : '#CBD5E1')}
      />
    </View>
  );
}

function SettingRowSelect({ icon, label, value, options, onSelect, isDark }: {
  icon: keyof typeof MaterialIcons.glyphMap;
  label: string;
  value: string;
  options: string[];
  onSelect: (v: string) => void;
  isDark: boolean;
}) {
  const [expanded, setExpanded] = useState(false);

  return (
    <View>
      <TouchableOpacity style={[styles.settingRow, isDark && { borderBottomColor: '#334155' }]} onPress={() => setExpanded(!expanded)} activeOpacity={0.7}>
        <View style={styles.settingIconContainer}>
          <MaterialIcons name={icon} size={20} color={BrandColors.accent} />
        </View>
        <View style={styles.settingContent}>
          <Text style={[styles.settingLabel, isDark && { color: '#F1F5F9' }]}>{label}</Text>
        </View>
        <View style={styles.selectValue}>
          <Text style={styles.selectValueText}>{value}</Text>
          <MaterialIcons name={expanded ? 'expand-less' : 'expand-more'} size={20} color={isDark ? '#94A3B8' : '#94A3B8'} />
        </View>
      </TouchableOpacity>
      {expanded && (
        <View style={styles.optionsContainer}>
          {options.map((opt) => (
            <TouchableOpacity
              key={opt}
              style={[styles.optionItem, value === opt && styles.optionItemActive, isDark && value === opt && { backgroundColor: BrandColors.accent + '20' }]}
              onPress={() => { onSelect(opt); setExpanded(false); }}
            >
              <Text style={[styles.optionText, isDark && { color: '#94A3B8' }, value === opt && styles.optionTextActive]}>{opt}</Text>
              {value === opt && <MaterialIcons name="check" size={18} color={BrandColors.accent} />}
            </TouchableOpacity>
          ))}
        </View>
      )}
    </View>
  );
}

function SettingRowAction({ icon, label, description, onPress, destructive, isDark }: {
  icon: keyof typeof MaterialIcons.glyphMap;
  label: string;
  description?: string;
  onPress: () => void;
  destructive?: boolean;
  isDark: boolean;
}) {
  return (
    <TouchableOpacity style={[styles.settingRow, isDark && { borderBottomColor: '#334155' }]} onPress={onPress} activeOpacity={0.7}>
      <View style={[styles.settingIconContainer, destructive && { backgroundColor: BrandColors.error + '12' }]}>
        <MaterialIcons name={icon} size={20} color={destructive ? BrandColors.error : BrandColors.accent} />
      </View>
      <View style={styles.settingContent}>
        <Text style={[styles.settingLabel, isDark && { color: '#F1F5F9' }, destructive && { color: BrandColors.error }]}>{label}</Text>
        {description && <Text style={[styles.settingDescription, isDark && { color: '#94A3B8' }]}>{description}</Text>}
      </View>
      <MaterialIcons name="chevron-right" size={20} color={isDark ? '#475569' : '#CBD5E1'} />
    </TouchableOpacity>
  );
}

function InfoRow({ label, value, isDark }: { label: string; value: string; isDark: boolean }) {
  return (
    <View style={[styles.infoRow, isDark && { borderBottomColor: '#334155' }]}>
      <Text style={[styles.infoLabel, isDark && { color: '#94A3B8' }]}>{label}</Text>
      <Text style={[styles.infoValue, isDark && { color: '#F1F5F9' }]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F1F5F9' } as any,
  header: {
    paddingTop: 56, paddingBottom: Spacing.lg, paddingHorizontal: Spacing.xl,
  },
  headerRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
  },
  backButton: {
    width: 40, height: 40, borderRadius: BorderRadius.full,
    backgroundColor: 'rgba(255,255,255,0.1)', justifyContent: 'center', alignItems: 'center',
  },
  headerTitle: { fontSize: Typography.sizes['2xl'], fontWeight: Typography.weights.bold, color: '#fff' },
  scroll: { flex: 1 },
  scrollContent: { paddingBottom: Spacing['2xl'] },

  sectionHeader: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm,
    paddingHorizontal: Spacing.xl, paddingTop: Spacing.xl, paddingBottom: Spacing.sm,
  },
  sectionTitle: { fontSize: Typography.sizes.sm, fontWeight: Typography.weights.bold, color: '#64748B', textTransform: 'uppercase', letterSpacing: 0.5 },

  card: {
    marginHorizontal: Spacing.xl, backgroundColor: '#fff',
    borderRadius: BorderRadius.lg, ...Shadows.sm, overflow: 'hidden',
  },

  // Profile
  profileRow: {
    flexDirection: 'row', alignItems: 'center', padding: Spacing.lg, gap: Spacing.md,
  },
  profileAvatar: {
    width: 48, height: 48, borderRadius: 24, justifyContent: 'center', alignItems: 'center',
  },
  profileAvatarText: { fontSize: Typography.sizes.lg, fontWeight: Typography.weights.bold, color: '#fff' },
  profileInfo: { flex: 1 },
  profileName: { fontSize: Typography.sizes.base, fontWeight: Typography.weights.bold, color: '#1A1A2E' },
  profileEmail: { fontSize: Typography.sizes.sm, color: '#64748B', marginTop: 1 },
  profileRole: { fontSize: Typography.sizes.xs, color: BrandColors.accent, fontWeight: Typography.weights.semibold, marginTop: 2 },

  // Setting Rows
  settingRow: {
    flexDirection: 'row', alignItems: 'center', paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md, gap: Spacing.md,
    borderBottomWidth: 1, borderBottomColor: '#F8FAFC',
  },
  settingIconContainer: {
    width: 36, height: 36, borderRadius: BorderRadius.md,
    backgroundColor: BrandColors.accent + '12', justifyContent: 'center', alignItems: 'center',
  },
  settingContent: { flex: 1 },
  settingLabel: { fontSize: Typography.sizes.md, fontWeight: Typography.weights.medium, color: '#1A1A2E' },
  settingDescription: { fontSize: Typography.sizes.xs, color: '#94A3B8', marginTop: 2 },

  selectValue: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  selectValueText: { fontSize: Typography.sizes.sm, color: BrandColors.accent, fontWeight: Typography.weights.semibold },

  optionsContainer: { paddingLeft: 68, paddingRight: Spacing.lg, paddingBottom: Spacing.sm },
  optionItem: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingVertical: Spacing.sm, paddingHorizontal: Spacing.md,
    borderRadius: BorderRadius.md, marginBottom: 2,
  },
  optionItemActive: { backgroundColor: BrandColors.accent + '10' },
  optionText: { fontSize: Typography.sizes.sm, color: '#64748B' },
  optionTextActive: { color: BrandColors.accent, fontWeight: Typography.weights.bold },

  infoRow: {
    flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md, borderBottomWidth: 1, borderBottomColor: '#F8FAFC',
  },
  infoLabel: { fontSize: Typography.sizes.md, color: '#64748B' },
  infoValue: { fontSize: Typography.sizes.md, fontWeight: Typography.weights.semibold, color: '#1A1A2E' },

  // Danger Zone
  dangerZone: { paddingHorizontal: Spacing.xl, marginTop: Spacing.xl, gap: Spacing.md },
  signOutButton: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    paddingVertical: Spacing.md, borderRadius: BorderRadius.lg,
    backgroundColor: BrandColors.error + '10', gap: Spacing.sm,
  },
  signOutText: { fontSize: Typography.sizes.md, fontWeight: Typography.weights.bold, color: BrandColors.error },
  deleteButton: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    paddingVertical: Spacing.md, borderRadius: BorderRadius.lg,
    backgroundColor: BrandColors.error, gap: Spacing.sm,
  },
  deleteText: { fontSize: Typography.sizes.md, fontWeight: Typography.weights.bold, color: '#fff' },
});
