/**
 * CampusMind AI - Registration Screen
 * Multi-step registration with academic role selection.
 */

import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { Link } from 'expo-router';
import { useAuth } from '@/contexts/AuthContext';
import { BrandColors, BorderRadius, Spacing, Typography, UserRoles, RoleLabels, UserRole } from '@/constants/theme';

const DEPARTMENTS = [
  'Computer Science',
  'Information Technology',
  'Engineering',
  'Business Administration',
  'Education',
  'Health Sciences',
  'Law',
  'Arts & Humanities',
  'Natural Sciences',
  'Social Sciences',
];

const FACULTIES = [
  'Faculty of Computing',
  'Faculty of Engineering',
  'Faculty of Business',
  'Faculty of Education',
  'Faculty of Health',
  'Faculty of Law',
  'Faculty of Arts',
  'Faculty of Science',
];

export default function RegisterScreen() {
  const { signUp, loading, error, clearError } = useAuth();
  const [step, setStep] = useState(1);
  const [focusedField, setFocusedField] = useState<string | null>(null);

  // Form state
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [designation, setDesignation] = useState('');
  const [department, setDepartment] = useState('');
  const [faculty, setFaculty] = useState('');
  const [role, setRole] = useState<UserRole>(UserRoles.LECTURER);
  const [showPassword, setShowPassword] = useState(false);

  const [validationError, setValidationError] = useState<string | null>('');

  const validateStep1 = () => {
    if (!name.trim()) return 'Please enter your full name';
    if (!email.trim()) return 'Please enter your email';
    if (!password.trim() || password.length < 6) return 'Password must be at least 6 characters';
    if (password !== confirmPassword) return 'Passwords do not match';
    return null;
  };

  const validateStep2 = () => {
    if (!designation.trim()) return 'Please enter your designation';
    if (!department.trim()) return 'Please select a department';
    if (!faculty.trim()) return 'Please select a faculty';
    return null;
  };

  const handleNext = () => {
    const err = validateStep1();
    if (err) {
      setValidationError(err);
      return;
    }
    setValidationError(null);
    setStep(2);
  };

  const handleRegister = async () => {
    const err = validateStep2();
    if (err) {
      setValidationError(err);
      return;
    }
    setValidationError(null);

    try {
      await signUp(email.trim(), password, {
        name: name.trim(),
        designation: designation.trim(),
        department,
        faculty,
        role,
      });
    } catch {
      // Error handled by context
    }
  };

  const roleOptions = Object.entries(UserRoles).map(([key, value]) => ({
    key,
    value,
    label: RoleLabels[value],
  }));

  const getRoleIcon = (roleValue: string): keyof typeof MaterialIcons.glyphMap => {
    switch (roleValue) {
      case UserRoles.TEACHING_ASSISTANT: return 'person-outline';
      case UserRoles.ASSISTANT_LECTURER: return 'record-voice-over';
      case UserRoles.LECTURER: return 'school';
      case UserRoles.SENIOR_LECTURER: return 'workspace-premium';
      case UserRoles.ASSOCIATE_PROFESSOR: return 'psychology';
      case UserRoles.PROFESSOR: return 'stars';
      case UserRoles.SENIOR_PROFESSOR: return 'military-tech';
      default: return 'person';
    }
  };

  return (
    <LinearGradient
      colors={['#0F172A', '#1B2A4A', '#1E3A5F']}
      style={styles.container}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
    >
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {/* Header */}
          <View style={styles.header}>
            {step === 2 && (
              <TouchableOpacity
                style={styles.backButton}
                onPress={() => {
                  setStep(1);
                  setValidationError(null);
                }}
              >
                <MaterialIcons name="arrow-back" size={24} color="#fff" />
              </TouchableOpacity>
            )}
            <View style={styles.brandContainer}>
              <View style={styles.logoContainer}>
                <LinearGradient
                  colors={[BrandColors.accent, BrandColors.secondary]}
                  style={styles.logoGradient}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                >
                  <MaterialIcons name="school" size={32} color="#fff" />
                </LinearGradient>
              </View>
              <Text style={styles.appName}>Create Account</Text>
              <Text style={styles.tagline}>Step {step} of 2 • {step === 1 ? 'Account Details' : 'Academic Profile'}</Text>
            </View>
          </View>

          {/* Progress Bar */}
          <View style={styles.progressContainer}>
            <View style={styles.progressTrack}>
              <LinearGradient
                colors={[BrandColors.accent, BrandColors.secondary]}
                style={[styles.progressFill, { width: `${(step / 2) * 100}%` }]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
              />
            </View>
          </View>

          {/* Card */}
          <View style={styles.card}>
            {/* Error */}
            {(error || validationError) && (
              <View style={styles.errorContainer}>
                <MaterialIcons name="error-outline" size={18} color={BrandColors.error} />
                <Text style={styles.errorText}>{validationError || error}</Text>
                <TouchableOpacity onPress={() => { clearError(); setValidationError(null); }}>
                  <MaterialIcons name="close" size={16} color={BrandColors.error} />
                </TouchableOpacity>
              </View>
            )}

            {/* Step 1: Account Details */}
            {step === 1 && (
              <>
                <InputField
                  label="Full Name"
                  icon="person"
                  placeholder="Enter your full name"
                  value={name}
                  onChangeText={setName}
                  focused={focusedField === 'name'}
                  onFocus={() => setFocusedField('name')}
                  onBlur={() => setFocusedField(null)}
                />
                <InputField
                  label="Email Address"
                  icon="email"
                  placeholder="Enter your institutional email"
                  value={email}
                  onChangeText={setEmail}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  focused={focusedField === 'email'}
                  onFocus={() => setFocusedField('email')}
                  onBlur={() => setFocusedField(null)}
                />
                <InputField
                  label="Password"
                  icon="lock"
                  placeholder="At least 6 characters"
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry={!showPassword}
                  focused={focusedField === 'password'}
                  onFocus={() => setFocusedField('password')}
                  onBlur={() => setFocusedField(null)}
                  rightIcon={
                    <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
                      <MaterialIcons name={showPassword ? 'visibility' : 'visibility-off'} size={20} color="#94A3B8" />
                    </TouchableOpacity>
                  }
                />
                <InputField
                  label="Confirm Password"
                  icon="lock-outline"
                  placeholder="Re-enter your password"
                  value={confirmPassword}
                  onChangeText={setConfirmPassword}
                  secureTextEntry={!showPassword}
                  focused={focusedField === 'confirmPassword'}
                  onFocus={() => setFocusedField('confirmPassword')}
                  onBlur={() => setFocusedField(null)}
                />

                <TouchableOpacity style={styles.primaryButton} onPress={handleNext} activeOpacity={0.8}>
                  <LinearGradient
                    colors={[BrandColors.accent, BrandColors.accentDark]}
                    style={styles.buttonGradient}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                  >
                    <Text style={styles.buttonText}>Continue</Text>
                    <MaterialIcons name="arrow-forward" size={20} color="#fff" />
                  </LinearGradient>
                </TouchableOpacity>
              </>
            )}

            {/* Step 2: Academic Profile */}
            {step === 2 && (
              <>
                <InputField
                  label="Designation / Title"
                  icon="badge"
                  placeholder="e.g., Senior Lecturer in Computing"
                  value={designation}
                  onChangeText={setDesignation}
                  focused={focusedField === 'designation'}
                  onFocus={() => setFocusedField('designation')}
                  onBlur={() => setFocusedField(null)}
                />

                {/* Department Picker */}
                <View style={styles.fieldContainer}>
                  <Text style={styles.fieldLabel}>Department</Text>
                  <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.chipScroll}>
                    {DEPARTMENTS.map((dept) => (
                      <TouchableOpacity
                        key={dept}
                        style={[styles.chip, department === dept && styles.chipSelected]}
                        onPress={() => setDepartment(dept)}
                      >
                        <Text style={[styles.chipText, department === dept && styles.chipTextSelected]}>
                          {dept}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </ScrollView>
                </View>

                {/* Faculty Picker */}
                <View style={styles.fieldContainer}>
                  <Text style={styles.fieldLabel}>Faculty</Text>
                  <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.chipScroll}>
                    {FACULTIES.map((fac) => (
                      <TouchableOpacity
                        key={fac}
                        style={[styles.chip, faculty === fac && styles.chipSelected]}
                        onPress={() => setFaculty(fac)}
                      >
                        <Text style={[styles.chipText, faculty === fac && styles.chipTextSelected]}>
                          {fac}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </ScrollView>
                </View>

                {/* Academic Role Selection */}
                <View style={styles.fieldContainer}>
                  <Text style={styles.fieldLabel}>Academic Role</Text>
                  <View style={styles.roleGrid}>
                    {roleOptions.map((r) => (
                      <TouchableOpacity
                        key={r.value}
                        style={[styles.roleCard, role === r.value && styles.roleCardSelected]}
                        onPress={() => setRole(r.value)}
                      >
                        <MaterialIcons
                          name={getRoleIcon(r.value)}
                          size={20}
                          color={role === r.value ? BrandColors.accent : '#64748B'}
                        />
                        <Text style={[styles.roleText, role === r.value && styles.roleTextSelected]}>
                          {r.label}
                        </Text>
                        {role === r.value && (
                          <MaterialIcons name="check-circle" size={16} color={BrandColors.accent} style={styles.roleCheck} />
                        )}
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>

                <TouchableOpacity
                  style={[styles.primaryButton, loading && styles.buttonDisabled]}
                  onPress={handleRegister}
                  disabled={loading}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={[BrandColors.accent, BrandColors.accentDark]}
                    style={styles.buttonGradient}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                  >
                    {loading ? (
                      <ActivityIndicator color="#fff" size="small" />
                    ) : (
                      <>
                        <Text style={styles.buttonText}>Create Account</Text>
                        <MaterialIcons name="check" size={20} color="#fff" />
                      </>
                    )}
                  </LinearGradient>
                </TouchableOpacity>
              </>
            )}

            {/* Login Link */}
            <View style={styles.linkContainer}>
              <Text style={styles.linkText}>Already have an account? </Text>
              <Link href="/login" asChild>
                <TouchableOpacity>
                  <Text style={styles.linkAction}>Sign In</Text>
                </TouchableOpacity>
              </Link>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}

// ─── Reusable Input Field ────────────────────────────────────
function InputField({
  label,
  icon,
  focused,
  rightIcon,
  ...props
}: {
  label: string;
  icon: keyof typeof MaterialIcons.glyphMap;
  focused: boolean;
  rightIcon?: React.ReactNode;
  onFocus: () => void;
  onBlur: () => void;
} & React.ComponentProps<typeof TextInput>) {
  return (
    <View style={styles.fieldContainer}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <View style={[styles.inputContainer, focused && styles.inputContainerFocused]}>
        <MaterialIcons name={icon} size={20} color={focused ? BrandColors.accent : '#94A3B8'} />
        <TextInput
          style={styles.input}
          placeholderTextColor="#64748B"
          {...props}
        />
        {rightIcon}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  keyboardView: { flex: 1 },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing['2xl'],
  },
  header: { marginBottom: Spacing.lg },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: BorderRadius.full,
    backgroundColor: 'rgba(255,255,255,0.08)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: Spacing.base,
  },
  brandContainer: { alignItems: 'center' },
  logoContainer: { marginBottom: Spacing.md },
  logoGradient: {
    width: 64,
    height: 64,
    borderRadius: BorderRadius.xl,
    justifyContent: 'center',
    alignItems: 'center',
  },
  appName: {
    fontSize: Typography.sizes['2xl'],
    fontWeight: Typography.weights.extrabold,
    color: '#FFFFFF',
    marginBottom: Spacing.xs,
  },
  tagline: {
    fontSize: Typography.sizes.sm,
    color: '#94A3B8',
    textAlign: 'center',
  },
  progressContainer: {
    marginBottom: Spacing.lg,
    paddingHorizontal: Spacing.xl,
  },
  progressTrack: {
    height: 4,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 2,
  },
  card: {
    backgroundColor: 'rgba(255,255,255,0.07)',
    borderRadius: BorderRadius['2xl'],
    padding: Spacing.xl,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  errorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: BrandColors.errorBg,
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    marginBottom: Spacing.base,
    gap: Spacing.sm,
  },
  errorText: {
    flex: 1,
    fontSize: Typography.sizes.sm,
    color: BrandColors.errorLight,
  },
  fieldContainer: { marginBottom: Spacing.base },
  fieldLabel: {
    fontSize: Typography.sizes.sm,
    fontWeight: Typography.weights.semibold,
    color: '#CBD5E1',
    marginBottom: Spacing.sm,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: BorderRadius.lg,
    paddingHorizontal: Spacing.base,
    paddingVertical: Platform.OS === 'ios' ? Spacing.md : Spacing.xs,
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.08)',
    gap: Spacing.md,
  },
  inputContainerFocused: {
    borderColor: BrandColors.accent,
    backgroundColor: 'rgba(0,180,216,0.06)',
  },
  input: {
    flex: 1,
    fontSize: Typography.sizes.base,
    color: '#FFFFFF',
    paddingVertical: Spacing.sm,
  },
  chipScroll: { marginTop: Spacing.xs },
  chip: {
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    marginRight: Spacing.sm,
  },
  chipSelected: {
    backgroundColor: 'rgba(0,180,216,0.15)',
    borderColor: BrandColors.accent,
  },
  chipText: {
    fontSize: Typography.sizes.sm,
    color: '#94A3B8',
  },
  chipTextSelected: {
    color: BrandColors.accentLight,
    fontWeight: Typography.weights.semibold,
  },
  roleGrid: { gap: Spacing.sm },
  roleCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.06)',
    gap: Spacing.md,
  },
  roleCardSelected: {
    backgroundColor: 'rgba(0,180,216,0.1)',
    borderColor: BrandColors.accent,
  },
  roleText: {
    flex: 1,
    fontSize: Typography.sizes.sm,
    color: '#94A3B8',
  },
  roleTextSelected: {
    color: BrandColors.accentLight,
    fontWeight: Typography.weights.semibold,
  },
  roleCheck: {
    marginLeft: 'auto',
  },
  primaryButton: {
    borderRadius: BorderRadius.lg,
    overflow: 'hidden',
    marginTop: Spacing.lg,
  },
  buttonDisabled: { opacity: 0.5 },
  buttonGradient: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: Spacing.base,
    gap: Spacing.sm,
  },
  buttonText: {
    fontSize: Typography.sizes.base,
    fontWeight: Typography.weights.bold,
    color: '#FFFFFF',
  },
  linkContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: Spacing.lg,
  },
  linkText: {
    fontSize: Typography.sizes.sm,
    color: '#94A3B8',
  },
  linkAction: {
    fontSize: Typography.sizes.sm,
    fontWeight: Typography.weights.bold,
    color: BrandColors.accentLight,
  },
});
