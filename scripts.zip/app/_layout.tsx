/**
 * CampusMind AI - Root Layout
 * Wraps the app with providers, adds sidebar navigation and floating AI button.
 * Theme is driven by SettingsContext (not just system preference).
 */

import React, { useState } from 'react';
import { View, TouchableOpacity, StyleSheet } from 'react-native';
import { DarkTheme, DefaultTheme, ThemeProvider } from '@react-navigation/native';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { MaterialIcons } from '@expo/vector-icons';
import 'react-native-reanimated';

import { SettingsProvider, useSettings } from '@/contexts/SettingsContext';
import { AuthProvider } from '@/contexts/AuthContext';
import Sidebar from '@/components/Sidebar';
import AIFloatingButton from '@/components/AIFloatingButton';
import { BrandColors } from '@/constants/theme';

const CampusMindLightTheme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    primary: '#00B4D8',
    background: '#F8FAFC',
    card: '#FFFFFF',
    text: '#1A1A2E',
    border: '#E2E8F0',
  },
};

const CampusMindDarkTheme = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    primary: '#48CAE4',
    background: '#0F172A',
    card: '#1E293B',
    text: '#F1F5F9',
    border: '#334155',
  },
};

// Inner component that reads from SettingsContext (must be inside SettingsProvider)
function AppInner() {
  const { resolvedTheme } = useSettings();
  const [sidebarVisible, setSidebarVisible] = useState(false);
  const isDark = resolvedTheme === 'dark';

  return (
    <AuthProvider>
      <ThemeProvider value={isDark ? CampusMindDarkTheme : CampusMindLightTheme}>
        <View style={[styles.rootContainer, { backgroundColor: isDark ? '#0F172A' : '#F8FAFC' }]}>
          <Stack>
            <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
            <Stack.Screen
              name="login"
              options={{ headerShown: false, presentation: 'fullScreenModal' }}
            />
            <Stack.Screen
              name="register"
              options={{ headerShown: false, presentation: 'fullScreenModal' }}
            />
            <Stack.Screen
              name="settings"
              options={{ headerShown: false, presentation: 'modal' }}
            />
            <Stack.Screen
              name="(institutional)"
              options={{ headerShown: false }}
            />
            <Stack.Screen name="modal" options={{ presentation: 'modal', title: 'Modal' }} />
          </Stack>

          {/* Floating Sidebar Toggle Button */}
          <TouchableOpacity
            style={[styles.sidebarToggle, isDark && styles.sidebarToggleDark]}
            onPress={() => setSidebarVisible(true)}
            activeOpacity={0.8}
          >
            <MaterialIcons name="menu" size={22} color="#fff" />
          </TouchableOpacity>

          {/* Floating AI Assistant Button */}
          <AIFloatingButton />

          {/* Sidebar Drawer */}
          <Sidebar
            visible={sidebarVisible}
            onClose={() => setSidebarVisible(false)}
          />
        </View>
        <StatusBar style={isDark ? 'light' : 'dark'} />
      </ThemeProvider>
    </AuthProvider>
  );
}

export default function RootLayout() {
  return (
    <SettingsProvider>
      <AppInner />
    </SettingsProvider>
  );
}

const styles = StyleSheet.create({
  rootContainer: { flex: 1 },
  sidebarToggle: {
    position: 'absolute',
    top: 52,
    left: 16,
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(15,23,42,0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 50,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5,
  },
  sidebarToggleDark: {
    backgroundColor: 'rgba(255,255,255,0.15)',
  },
});
