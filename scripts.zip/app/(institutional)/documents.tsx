/**
 * CampusMind AI - QA Documents Repository
 * Centralized, searchable repository for QA evidence and policies.
 */

import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { BrandColors, BorderRadius, Spacing, Typography, Shadows } from '@/constants/theme';

const CATEGORIES = ['All', 'Policies', 'Evidence', 'Minutes', 'Reports', 'Templates'];

const MOCK_DOCUMENTS = [
  { id: '1', name: 'Assessment Policy 2026-27', category: 'Policies', type: 'pdf', size: '245 KB', date: '2026-08-01', uploader: 'QA Unit' },
  { id: '2', name: 'Faculty Board Minutes - Aug 2026', category: 'Minutes', type: 'docx', size: '89 KB', date: '2026-08-15', uploader: 'Dr. Patel' },
  { id: '3', name: 'Student Feedback Survey Results', category: 'Evidence', type: 'xlsx', size: '1.2 MB', date: '2026-07-20', uploader: 'Registry' },
  { id: '4', name: 'Programme Specification - CS BSc', category: 'Policies', type: 'pdf', size: '320 KB', date: '2026-06-10', uploader: 'QA Unit' },
  { id: '5', name: 'External Examiner Report 2025-26', category: 'Reports', type: 'pdf', size: '156 KB', date: '2026-07-05', uploader: 'External' },
  { id: '6', name: 'APM Report Template', category: 'Templates', type: 'docx', size: '45 KB', date: '2026-01-15', uploader: 'QA Unit' },
  { id: '7', name: 'Lab Equipment Audit Evidence', category: 'Evidence', type: 'zip', size: '4.8 MB', date: '2026-08-12', uploader: 'Lab Manager' },
  { id: '8', name: 'Curriculum Review Meeting Notes', category: 'Minutes', type: 'pdf', size: '78 KB', date: '2026-08-18', uploader: 'Dr. Ahmed' },
];

const FILE_ICONS: Record<string, { icon: keyof typeof MaterialIcons.glyphMap; color: string }> = {
  pdf: { icon: 'picture-as-pdf', color: '#EF4444' },
  docx: { icon: 'description', color: '#3B82F6' },
  xlsx: { icon: 'table-chart', color: '#10B981' },
  zip: { icon: 'folder-zip', color: '#F59E0B' },
};

export default function DocumentsScreen() {
  const [activeCategory, setActiveCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  const filtered = MOCK_DOCUMENTS.filter((doc) => {
    const matchesCategory = activeCategory === 'All' || doc.category === activeCategory;
    const matchesSearch = doc.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#1B2A4A', '#0F172A']} style={styles.header}>
        <Text style={styles.headerTitle}>QA Documents</Text>
        <Text style={styles.headerSubtitle}>{MOCK_DOCUMENTS.length} documents • Centralized repository</Text>

        {/* Search */}
        <View style={styles.searchBar}>
          <MaterialIcons name="search" size={20} color="#94A3B8" />
          <TextInput
            style={styles.searchInput}
            placeholder="Search documents..."
            placeholderTextColor="#64748B"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity onPress={() => setSearchQuery('')}>
              <MaterialIcons name="close" size={18} color="#94A3B8" />
            </TouchableOpacity>
          )}
        </View>
      </LinearGradient>

      {/* Category Filter */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoryScroll} contentContainerStyle={styles.categoryContent}>
        {CATEGORIES.map((cat) => (
          <TouchableOpacity
            key={cat}
            style={[styles.categoryChip, activeCategory === cat && styles.categoryChipActive]}
            onPress={() => setActiveCategory(cat)}
          >
            <Text style={[styles.categoryText, activeCategory === cat && styles.categoryTextActive]}>{cat}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Document List */}
      <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {filtered.length === 0 ? (
          <View style={styles.emptyState}>
            <MaterialIcons name="search-off" size={48} color="#CBD5E1" />
            <Text style={styles.emptyText}>No documents found</Text>
          </View>
        ) : (
          filtered.map((doc) => {
            const fileConfig = FILE_ICONS[doc.type] || { icon: 'insert-drive-file', color: '#64748B' };
            return (
              <TouchableOpacity key={doc.id} style={styles.docCard} activeOpacity={0.7}>
                <View style={[styles.fileIcon, { backgroundColor: fileConfig.color + '12' }]}>
                  <MaterialIcons name={fileConfig.icon} size={22} color={fileConfig.color} />
                </View>
                <View style={styles.docContent}>
                  <Text style={styles.docName} numberOfLines={1}>{doc.name}</Text>
                  <Text style={styles.docMeta}>{doc.category} • {doc.size} • {doc.date}</Text>
                  <Text style={styles.docUploader}>Uploaded by {doc.uploader}</Text>
                </View>
                <TouchableOpacity style={styles.downloadButton}>
                  <MaterialIcons name="download" size={20} color={BrandColors.accent} />
                </TouchableOpacity>
              </TouchableOpacity>
            );
          })
        )}

        {/* Upload Button */}
        <TouchableOpacity style={styles.uploadButton} activeOpacity={0.8}>
          <LinearGradient colors={[BrandColors.secondary, BrandColors.accent]} style={styles.uploadGradient}>
            <MaterialIcons name="cloud-upload" size={20} color="#fff" />
            <Text style={styles.uploadText}>Upload Document</Text>
          </LinearGradient>
        </TouchableOpacity>

        <View style={{ height: Spacing['3xl'] }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  header: {
    paddingTop: 56, paddingHorizontal: Spacing.xl, paddingBottom: Spacing.xl,
    borderBottomLeftRadius: BorderRadius['2xl'], borderBottomRightRadius: BorderRadius['2xl'],
  },
  headerTitle: { fontSize: Typography.sizes['2xl'], fontWeight: Typography.weights.bold, color: '#fff' },
  headerSubtitle: { fontSize: Typography.sizes.sm, color: '#94A3B8', marginTop: 2, marginBottom: Spacing.lg },
  searchBar: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: BorderRadius.lg, paddingHorizontal: Spacing.md, gap: Spacing.sm,
  },
  searchInput: { flex: 1, paddingVertical: Spacing.md, fontSize: Typography.sizes.md, color: '#fff' },
  categoryScroll: { maxHeight: 48 },
  categoryContent: { paddingHorizontal: Spacing.xl, paddingVertical: Spacing.sm, gap: Spacing.sm },
  categoryChip: {
    paddingHorizontal: Spacing.base, paddingVertical: 6,
    borderRadius: BorderRadius.full, backgroundColor: '#F1F5F9',
  },
  categoryChipActive: { backgroundColor: BrandColors.secondary },
  categoryText: { fontSize: Typography.sizes.sm, color: '#64748B', fontWeight: Typography.weights.medium },
  categoryTextActive: { color: '#fff', fontWeight: Typography.weights.bold },
  scroll: { flex: 1 },
  scrollContent: { padding: Spacing.xl },
  docCard: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff',
    borderRadius: BorderRadius.lg, padding: Spacing.base, marginBottom: Spacing.sm,
    gap: Spacing.md, ...Shadows.sm,
  },
  fileIcon: {
    width: 44, height: 44, borderRadius: BorderRadius.md, justifyContent: 'center', alignItems: 'center',
  },
  docContent: { flex: 1 },
  docName: { fontSize: Typography.sizes.md, fontWeight: Typography.weights.semibold, color: '#1A1A2E' },
  docMeta: { fontSize: Typography.sizes.xs, color: '#94A3B8', marginTop: 2 },
  docUploader: { fontSize: Typography.sizes.xs, color: '#CBD5E1', marginTop: 1 },
  downloadButton: {
    width: 36, height: 36, borderRadius: BorderRadius.full,
    backgroundColor: BrandColors.accent + '12', justifyContent: 'center', alignItems: 'center',
  },
  uploadButton: { borderRadius: BorderRadius.lg, overflow: 'hidden', marginTop: Spacing.lg },
  uploadGradient: {
    flexDirection: 'row', justifyContent: 'center', alignItems: 'center',
    paddingVertical: Spacing.base, gap: Spacing.sm,
  },
  uploadText: { fontSize: Typography.sizes.md, fontWeight: Typography.weights.bold, color: '#fff' },
  emptyState: { alignItems: 'center', paddingVertical: Spacing['3xl'], gap: Spacing.md },
  emptyText: { fontSize: Typography.sizes.md, color: '#94A3B8' },
});
