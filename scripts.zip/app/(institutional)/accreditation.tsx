/**
 * CampusMind AI - Accreditation Tracker
 * Countdown trackers and milestone management for educational accreditations.
 */

import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { BrandColors, BorderRadius, Spacing, Typography, Shadows } from '@/constants/theme';
import { useSettings } from '@/contexts/SettingsContext';

const MOCK_ACCREDITATIONS = [
  {
    id: '1', body: 'ABET (Computing)', programme: 'BSc Computer Science',
    deadline: '2027-03-15', daysLeft: 205, status: 'on_track',
    progress: 68, milestones: [
      { name: 'Self-Study Report Draft', done: true },
      { name: 'Evidence Collection', done: true },
      { name: 'External Evaluator Nomination', done: false },
      { name: 'Mock Audit', done: false },
      { name: 'Final Submission', done: false },
    ],
  },
  {
    id: '2', body: 'QAA (Institutional)', programme: 'Institution-wide',
    deadline: '2026-12-01', daysLeft: 100, status: 'at_risk',
    progress: 45, milestones: [
      { name: 'Action Plan Submitted', done: true },
      { name: 'Student Survey Completed', done: true },
      { name: 'Enhancement Plan Draft', done: false },
      { name: 'External Panel Arranged', done: false },
      { name: 'Documentation Review', done: false },
    ],
  },
];

export default function AccreditationScreen() {
  const { resolvedTheme } = useSettings();
  const isDark = resolvedTheme === 'dark';

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'on_track': return { label: 'On Track', color: BrandColors.success, bg: BrandColors.successBg };
      case 'at_risk': return { label: 'At Risk', color: BrandColors.warning, bg: BrandColors.warningBg };
      case 'overdue': return { label: 'Overdue', color: BrandColors.error, bg: BrandColors.errorBg };
      default: return { label: status, color: '#64748B', bg: '#F1F5F9' };
    }
  };

  return (
    <View style={[styles.container, isDark && styles.containerDark]}>
      <LinearGradient colors={['#1B2A4A', '#0F172A']} style={styles.header}>
        <Text style={styles.headerTitle}>Accreditation Tracker</Text>
        <Text style={styles.headerSubtitle}>Manage accreditation milestones & deadlines</Text>
      </LinearGradient>

      <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {MOCK_ACCREDITATIONS.map((acc) => {
          const statusConfig = getStatusConfig(acc.status);
          const completedCount = acc.milestones.filter((m) => m.done).length;

          return (
            <View key={acc.id} style={[styles.card, isDark && styles.cardDark]}>
              <View style={styles.cardHeader}>
                <View style={styles.cardHeaderLeft}>
                  <Text style={[styles.bodyName, isDark && styles.textDark]}>{acc.body}</Text>
                  <Text style={[styles.programmeName, isDark && styles.textMutedDark]}>{acc.programme}</Text>
                </View>
                <View style={[styles.statusBadge, { backgroundColor: statusConfig.bg }]}>
                  <Text style={[styles.statusText, { color: statusConfig.color }]}>{statusConfig.label}</Text>
                </View>
              </View>

              {/* Countdown */}
              <View style={[styles.countdownRow, isDark && styles.countdownRowDark, { borderColor: statusConfig.color + (isDark ? '20' : '30') }]}>
                <MaterialIcons name="timer" size={20} color={statusConfig.color} />
                <Text style={[styles.countdownDays, { color: statusConfig.color }]}>{acc.daysLeft}</Text>
                <Text style={[styles.countdownLabel, isDark && styles.textMutedDark]}>days remaining</Text>
                <Text style={[styles.deadlineDate, isDark && styles.textMutedDark]}>Due: {acc.deadline}</Text>
              </View>

              {/* Progress */}
              <View style={styles.progressSection}>
                <View style={styles.progressHeader}>
                  <Text style={[styles.progressLabel, isDark && styles.textMutedDark]}>Overall Progress</Text>
                  <Text style={[styles.progressPercent, isDark && styles.textDark]}>{acc.progress}%</Text>
                </View>
                <View style={[styles.progressTrack, isDark && styles.progressTrackDark]}>
                  <LinearGradient
                    colors={[statusConfig.color, statusConfig.color + '80']}
                    style={[styles.progressFill, { width: `${acc.progress}%` }]}
                    start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                  />
                </View>
              </View>

              {/* Milestones */}
              <Text style={[styles.milestonesTitle, isDark && styles.textDark]}>Milestones ({completedCount}/{acc.milestones.length})</Text>
              {acc.milestones.map((m, i) => (
                <View key={i} style={styles.milestoneRow}>
                  <MaterialIcons
                    name={m.done ? 'check-circle' : 'radio-button-unchecked'}
                    size={20}
                    color={m.done ? BrandColors.success : (isDark ? '#475569' : '#CBD5E1')}
                  />
                  <Text style={[styles.milestoneText, isDark && styles.textDark, m.done && styles.milestoneDone, isDark && m.done && styles.milestoneDoneDark]}>{m.name}</Text>
                </View>
              ))}
            </View>
          );
        })}
        <View style={{ height: Spacing['3xl'] }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  containerDark: { backgroundColor: '#0F172A' },
  header: {
    paddingTop: 56, paddingHorizontal: Spacing.xl, paddingBottom: Spacing.xl,
    borderBottomLeftRadius: BorderRadius['2xl'], borderBottomRightRadius: BorderRadius['2xl'],
  },
  headerTitle: { fontSize: Typography.sizes['2xl'], fontWeight: Typography.weights.bold, color: '#fff' },
  headerSubtitle: { fontSize: Typography.sizes.sm, color: '#94A3B8', marginTop: 2 },
  scroll: { flex: 1 },
  scrollContent: { padding: Spacing.xl },
  card: { backgroundColor: '#fff', borderRadius: BorderRadius.lg, padding: Spacing.lg, marginBottom: Spacing.lg, ...Shadows.sm },
  cardDark: { backgroundColor: '#1E293B' },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: Spacing.md },
  cardHeaderLeft: { flex: 1 },
  bodyName: { fontSize: Typography.sizes.lg, fontWeight: Typography.weights.bold, color: '#1A1A2E' },
  programmeName: { fontSize: Typography.sizes.sm, color: '#64748B', marginTop: 2 },
  textDark: { color: '#F1F5F9' },
  textMutedDark: { color: '#94A3B8' },
  statusBadge: { paddingHorizontal: Spacing.md, paddingVertical: 4, borderRadius: BorderRadius.sm },
  statusText: { fontSize: 11, fontWeight: Typography.weights.bold, textTransform: 'uppercase' },
  countdownRow: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, backgroundColor: '#F8FAFC',
    padding: Spacing.md, borderRadius: BorderRadius.md, marginBottom: Spacing.md, borderWidth: 1,
  },
  countdownRowDark: { backgroundColor: '#0F172A' },
  countdownDays: { fontSize: Typography.sizes['2xl'], fontWeight: Typography.weights.extrabold },
  countdownLabel: { fontSize: Typography.sizes.sm, color: '#64748B' },
  deadlineDate: { fontSize: Typography.sizes.xs, color: '#94A3B8', marginLeft: 'auto' },
  progressSection: { marginBottom: Spacing.md },
  progressHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  progressLabel: { fontSize: Typography.sizes.sm, color: '#64748B' },
  progressPercent: { fontSize: Typography.sizes.sm, fontWeight: Typography.weights.bold, color: '#1A1A2E' },
  progressTrack: { height: 6, backgroundColor: '#F1F5F9', borderRadius: 3, overflow: 'hidden' },
  progressTrackDark: { backgroundColor: '#334155' },
  progressFill: { height: '100%', borderRadius: 3 },
  milestonesTitle: { fontSize: Typography.sizes.sm, fontWeight: Typography.weights.bold, color: '#334155', marginBottom: Spacing.sm },
  milestoneRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, paddingVertical: 6 },
  milestoneText: { fontSize: Typography.sizes.md, color: '#334155' },
  milestoneDone: { color: '#94A3B8', textDecorationLine: 'line-through' },
  milestoneDoneDark: { color: '#475569' },
});
