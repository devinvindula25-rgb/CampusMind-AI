/**
 * CampusMind AI - Academic Audits
 * Internal self-evaluation and external audit preparation tools.
 */

import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { BrandColors, BorderRadius, Spacing, Typography, Shadows } from '@/constants/theme';

const MOCK_AUDITS = [
  {
    id: '1', title: 'Annual Internal QA Audit 2026', type: 'internal',
    department: 'Computer Science', status: 'in_progress', date: '2026-09-15',
    findings: [
      { text: 'Student feedback loop needs improvement', severity: 'major', status: 'open' },
      { text: 'Lab equipment inventory outdated', severity: 'minor', status: 'resolved' },
      { text: 'Assessment moderation records incomplete', severity: 'major', status: 'in_progress' },
    ],
    evidenceProgress: 72,
  },
  {
    id: '2', title: 'ABET Site Visit Preparation', type: 'external',
    department: 'Computer Science', status: 'planning', date: '2027-03-01',
    findings: [],
    evidenceProgress: 35,
  },
];

const CHECKLIST = [
  { id: '1', text: 'Programme learning outcomes documented', done: true },
  { id: '2', text: 'Course syllabi updated for current year', done: true },
  { id: '3', text: 'Student work samples collected (A, B, C grades)', done: false },
  { id: '4', text: 'Faculty qualifications matrix updated', done: true },
  { id: '5', text: 'Assessment rubrics aligned with outcomes', done: false },
  { id: '6', text: 'Advisory board meeting minutes uploaded', done: false },
  { id: '7', text: 'Continuous improvement actions documented', done: true },
  { id: '8', text: 'Lab safety certificates renewed', done: true },
];

export default function AuditsScreen() {
  const [activeTab, setActiveTab] = useState<'audits' | 'checklist'>('audits');
  const completedChecks = CHECKLIST.filter((c) => c.done).length;

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#1B2A4A', '#0F172A']} style={styles.header}>
        <Text style={styles.headerTitle}>Academic Audits</Text>
        <Text style={styles.headerSubtitle}>Self-evaluation & audit preparation</Text>
      </LinearGradient>

      {/* Tab Switcher */}
      <View style={styles.tabRow}>
        <TouchableOpacity style={[styles.tab, activeTab === 'audits' && styles.tabActive]} onPress={() => setActiveTab('audits')}>
          <Text style={[styles.tabText, activeTab === 'audits' && styles.tabTextActive]}>Audits</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.tab, activeTab === 'checklist' && styles.tabActive]} onPress={() => setActiveTab('checklist')}>
          <Text style={[styles.tabText, activeTab === 'checklist' && styles.tabTextActive]}>Audit Checklist</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {activeTab === 'audits' ? (
          MOCK_AUDITS.map((audit) => (
            <View key={audit.id} style={styles.card}>
              <View style={styles.cardHeader}>
                <View style={styles.typeBadge}>
                  <MaterialIcons name={audit.type === 'internal' ? 'fact-check' : 'public'} size={14} color={BrandColors.secondary} />
                  <Text style={styles.typeText}>{audit.type === 'internal' ? 'Internal' : 'External'}</Text>
                </View>
                <StatusBadge status={audit.status} />
              </View>
              <Text style={styles.auditTitle}>{audit.title}</Text>
              <Text style={styles.auditMeta}>{audit.department} • Scheduled: {audit.date}</Text>

              {/* Evidence Progress */}
              <View style={styles.evidenceSection}>
                <Text style={styles.evidenceLabel}>Evidence Collection</Text>
                <View style={styles.progressRow}>
                  <View style={styles.progressTrack}>
                    <LinearGradient
                      colors={[BrandColors.secondary, BrandColors.accent]}
                      style={[styles.progressFill, { width: `${audit.evidenceProgress}%` }]}
                      start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                    />
                  </View>
                  <Text style={styles.progressPercent}>{audit.evidenceProgress}%</Text>
                </View>
              </View>

              {/* Findings */}
              {audit.findings.length > 0 && (
                <View style={styles.findingsSection}>
                  <Text style={styles.findingsTitle}>Findings ({audit.findings.length})</Text>
                  {audit.findings.map((f, i) => (
                    <View key={i} style={styles.findingRow}>
                      <View style={[styles.severityDot, {
                        backgroundColor: f.severity === 'major' ? BrandColors.error : BrandColors.warning,
                      }]} />
                      <Text style={styles.findingText}>{f.text}</Text>
                      <FindingStatus status={f.status} />
                    </View>
                  ))}
                </View>
              )}
            </View>
          ))
        ) : (
          <View style={styles.card}>
            <View style={styles.checklistHeader}>
              <Text style={styles.checklistTitle}>Audit Readiness Checklist</Text>
              <Text style={styles.checklistProgress}>{completedChecks}/{CHECKLIST.length} complete</Text>
            </View>
            <View style={styles.checklistProgressBar}>
              <LinearGradient
                colors={[BrandColors.success, BrandColors.accent]}
                style={[styles.progressFill, { width: `${(completedChecks / CHECKLIST.length) * 100}%` }]}
                start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
              />
            </View>
            {CHECKLIST.map((item) => (
              <TouchableOpacity key={item.id} style={styles.checkItem}>
                <MaterialIcons
                  name={item.done ? 'check-box' : 'check-box-outline-blank'}
                  size={22}
                  color={item.done ? BrandColors.success : '#CBD5E1'}
                />
                <Text style={[styles.checkText, item.done && styles.checkTextDone]}>{item.text}</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}
        <View style={{ height: Spacing['3xl'] }} />
      </ScrollView>
    </View>
  );
}

function StatusBadge({ status }: { status: string }) {
  const config: Record<string, { label: string; color: string; bg: string }> = {
    planning: { label: 'Planning', color: '#64748B', bg: '#F1F5F9' },
    in_progress: { label: 'In Progress', color: BrandColors.info, bg: BrandColors.infoBg },
    completed: { label: 'Completed', color: BrandColors.success, bg: BrandColors.successBg },
  };
  const c = config[status] || config.planning;
  return (
    <View style={[styles.statusBadge, { backgroundColor: c.bg }]}>
      <Text style={[styles.statusText, { color: c.color }]}>{c.label}</Text>
    </View>
  );
}

function FindingStatus({ status }: { status: string }) {
  const config: Record<string, { label: string; color: string }> = {
    open: { label: 'Open', color: BrandColors.error },
    in_progress: { label: 'Fixing', color: BrandColors.warning },
    resolved: { label: 'Resolved', color: BrandColors.success },
  };
  const c = config[status] || config.open;
  return <Text style={[styles.findingStatus, { color: c.color }]}>{c.label}</Text>;
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  header: {
    paddingTop: 56, paddingHorizontal: Spacing.xl, paddingBottom: Spacing.xl,
    borderBottomLeftRadius: BorderRadius['2xl'], borderBottomRightRadius: BorderRadius['2xl'],
  },
  headerTitle: { fontSize: Typography.sizes['2xl'], fontWeight: Typography.weights.bold, color: '#fff' },
  headerSubtitle: { fontSize: Typography.sizes.sm, color: '#94A3B8', marginTop: 2 },
  tabRow: {
    flexDirection: 'row', paddingHorizontal: Spacing.xl, paddingVertical: Spacing.md,
    gap: Spacing.sm, borderBottomWidth: 1, borderBottomColor: '#E2E8F0',
  },
  tab: { flex: 1, paddingVertical: Spacing.sm, borderRadius: BorderRadius.md, alignItems: 'center' },
  tabActive: { backgroundColor: BrandColors.secondary + '15' },
  tabText: { fontSize: Typography.sizes.md, color: '#94A3B8', fontWeight: Typography.weights.medium },
  tabTextActive: { color: BrandColors.secondary, fontWeight: Typography.weights.bold },
  scroll: { flex: 1 },
  scrollContent: { padding: Spacing.xl },
  card: { backgroundColor: '#fff', borderRadius: BorderRadius.lg, padding: Spacing.lg, marginBottom: Spacing.lg, ...Shadows.sm },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: Spacing.sm },
  typeBadge: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  typeText: { fontSize: Typography.sizes.xs, color: BrandColors.secondary, fontWeight: Typography.weights.bold, textTransform: 'uppercase' },
  statusBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: BorderRadius.sm },
  statusText: { fontSize: 10, fontWeight: Typography.weights.bold, textTransform: 'uppercase' },
  auditTitle: { fontSize: Typography.sizes.lg, fontWeight: Typography.weights.bold, color: '#1A1A2E', marginBottom: 4 },
  auditMeta: { fontSize: Typography.sizes.sm, color: '#64748B', marginBottom: Spacing.md },
  evidenceSection: { marginBottom: Spacing.md },
  evidenceLabel: { fontSize: Typography.sizes.sm, color: '#64748B', marginBottom: 6 },
  progressRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  progressTrack: { flex: 1, height: 6, backgroundColor: '#F1F5F9', borderRadius: 3, overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 3 },
  progressPercent: { fontSize: Typography.sizes.sm, fontWeight: Typography.weights.bold, color: '#334155' },
  findingsSection: { borderTopWidth: 1, borderTopColor: '#F1F5F9', paddingTop: Spacing.md },
  findingsTitle: { fontSize: Typography.sizes.sm, fontWeight: Typography.weights.bold, color: '#334155', marginBottom: Spacing.sm },
  findingRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, paddingVertical: 6 },
  severityDot: { width: 8, height: 8, borderRadius: 4 },
  findingText: { flex: 1, fontSize: Typography.sizes.sm, color: '#334155' },
  findingStatus: { fontSize: 10, fontWeight: Typography.weights.bold, textTransform: 'uppercase' },
  checklistHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: Spacing.md },
  checklistTitle: { fontSize: Typography.sizes.lg, fontWeight: Typography.weights.bold, color: '#1A1A2E' },
  checklistProgress: { fontSize: Typography.sizes.sm, color: BrandColors.success, fontWeight: Typography.weights.bold },
  checklistProgressBar: { height: 6, backgroundColor: '#F1F5F9', borderRadius: 3, overflow: 'hidden', marginBottom: Spacing.lg },
  checkItem: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, paddingVertical: Spacing.sm },
  checkText: { flex: 1, fontSize: Typography.sizes.md, color: '#334155' },
  checkTextDone: { color: '#94A3B8', textDecorationLine: 'line-through' },
});
