/**
 * CampusMind AI - Institutional QA Hub Layout
 * Tab navigation for the institutional workspace.
 */

import { Tabs } from 'expo-router';
import React from 'react';
import { Platform } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { BrandColors, Shadows } from '@/constants/theme';
import { useSettings } from '@/contexts/SettingsContext';

export default function InstitutionalLayout() {
  const { settings, resolvedTheme } = useSettings();
  const isDark = resolvedTheme === 'dark';
  const isSidebarMode = settings.navigationMode === 'sidebar';
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: BrandColors.secondary,
        tabBarInactiveTintColor: isDark ? '#64748B' : '#94A3B8',
        tabBarStyle: {
          display: isSidebarMode ? 'none' : 'flex',
          backgroundColor: isDark ? '#1E293B' : '#FFFFFF',
          borderTopWidth: 0,
          height: Platform.OS === 'ios' ? 88 : 68,
          paddingBottom: Platform.OS === 'ios' ? 28 : 10,
          paddingTop: 8,
          ...Shadows.lg,
        },
        tabBarLabelStyle: { fontSize: 10, fontWeight: '600', marginTop: 2 },
      }}
    >
      <Tabs.Screen
        name="accreditation"
        options={{
          title: 'Accredit.',
          tabBarIcon: ({ color }) => <MaterialIcons name="verified" size={22} color={color} />,
        }}
      />
      <Tabs.Screen
        name="curriculum"
        options={{
          title: 'Curriculum',
          tabBarIcon: ({ color }) => <MaterialIcons name="menu-book" size={22} color={color} />,
        }}
      />
      <Tabs.Screen
        name="audits"
        options={{
          title: 'Audits',
          tabBarIcon: ({ color }) => <MaterialIcons name="fact-check" size={22} color={color} />,
        }}
      />
      <Tabs.Screen
        name="reports"
        options={{
          title: 'Reports',
          tabBarIcon: ({ color }) => <MaterialIcons name="description" size={22} color={color} />,
        }}
      />
      <Tabs.Screen
        name="documents"
        options={{
          title: 'Docs',
          tabBarIcon: ({ color }) => <MaterialIcons name="folder" size={22} color={color} />,
        }}
      />
    </Tabs>
  );
}
