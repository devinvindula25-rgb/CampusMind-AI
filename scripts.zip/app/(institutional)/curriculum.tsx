/**
 * CampusMind AI - Curriculum Reviews
 * Propose → Review → Approve pipeline for syllabus changes.
 */

import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { BrandColors, BorderRadius, Spacing, Typography, Shadows } from '@/constants/theme';

const PIPELINE_STAGES = ['Proposed', 'Under Review', 'Approved'];

const MOCK_REVIEWS = [
  { id: '1', title: 'Add AI Ethics Module to CS301', programme: 'BSc Computer Science', proposer: 'Dr. Ahmed', date: '2026-08-10', stage: 0, priority: 'high' },
  { id: '2', title: 'Update Data Structures Lab Content', programme: 'BSc Computer Science', proposer: 'Dr. Patel', date: '2026-08-12', stage: 1, priority: 'medium' },
  { id: '3', title: 'Remove Legacy COBOL Module', programme: 'BSc IT', proposer: 'Prof. Williams', date: '2026-07-20', stage: 1, priority: 'low' },
  { id: '4', title: 'Introduce Cloud Computing Elective', programme: 'MSc Computer Science', proposer: 'Dr. Chen', date: '2026-06-15', stage: 2, priority: 'medium' },
  { id: '5', title: 'Revise Cybersecurity Syllabus', programme: 'BSc Cybersecurity', proposer: 'Dr. Bennett', date: '2026-08-18', stage: 0, priority: 'high' },
];

export default function CurriculumScreen() {
  const [activeStage, setActiveStage] = useState(0);

  const filteredReviews = MOCK_REVIEWS.filter((r) => r.stage === activeStage);
  const stageCounts = PIPELINE_STAGES.map((_, i) => MOCK_REVIEWS.filter((r) => r.stage === i).length);

  const getPriorityConfig = (p: string) => {
    switch (p) {
      case 'high': return { label: 'High', color: BrandColors.error, bg: BrandColors.errorBg };
      case 'medium': return { label: 'Medium', color: BrandColors.warning, bg: BrandColors.warningBg };
      default: return { label: 'Low', color: '#64748B', bg: '#F1F5F9' };
    }
  };

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#1B2A4A', '#0F172A']} style={styles.header}>
        <Text style={styles.headerTitle}>Curriculum Reviews</Text>
        <Text style={styles.headerSubtitle}>Manage syllabus change proposals</Text>
      </LinearGradient>

      {/* Kanban Stage Tabs */}
      <View style={styles.stageRow}>
        {PIPELINE_STAGES.map((stage, i) => (
          <TouchableOpacity
            key={stage}
            style={[styles.stageTab, activeStage === i && styles.stageTabActive]}
            onPress={() => setActiveStage(i)}
          >
            <Text style={[styles.stageTabText, activeStage === i && styles.stageTabTextActive]}>{stage}</Text>
            <View style={[styles.stageBadge, activeStage === i && styles.stageBadgeActive]}>
              <Text style={[styles.stageBadgeText, activeStage === i && styles.stageBadgeTextActive]}>{stageCounts[i]}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {filteredReviews.length === 0 ? (
          <View style={styles.emptyState}>
            <MaterialIcons name="inbox" size={48} color="#CBD5E1" />
            <Text style={styles.emptyText}>No reviews in this stage</Text>
          </View>
        ) : (
          filteredReviews.map((review) => {
            const priority = getPriorityConfig(review.priority);
            return (
              <TouchableOpacity key={review.id} style={styles.card} activeOpacity={0.7}>
                <View style={styles.cardHeader}>
                  <Text style={styles.cardTitle}>{review.title}</Text>
                  <View style={[styles.priorityBadge, { backgroundColor: priority.bg }]}>
                    <Text style={[styles.priorityText, { color: priority.color }]}>{priority.label}</Text>
                  </View>
                </View>
                <Text style={styles.programme}>{review.programme}</Text>
                <View style={styles.metaRow}>
                  <View style={styles.metaItem}>
                    <MaterialIcons name="person" size={14} color="#94A3B8" />
                    <Text style={styles.metaText}>{review.proposer}</Text>
                  </View>
                  <View style={styles.metaItem}>
                    <MaterialIcons name="calendar-today" size={14} color="#94A3B8" />
                    <Text style={styles.metaText}>{review.date}</Text>
                  </View>
                </View>
                {activeStage < 2 && (
                  <View style={styles.actionRow}>
                    <TouchableOpacity style={styles.approveButton}>
                      <MaterialIcons name="check" size={16} color={BrandColors.success} />
                      <Text style={styles.approveText}>{activeStage === 0 ? 'Send to Review' : 'Approve'}</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.rejectButton}>
                      <MaterialIcons name="close" size={16} color={BrandColors.error} />
                      <Text style={styles.rejectText}>Reject</Text>
                    </TouchableOpacity>
                  </View>
                )}
              </TouchableOpacity>
            );
          })
        )}
        <View style={{ height: Spacing['3xl'] }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  header: {
    paddingTop: 56, paddingHorizontal: Spacing.xl, paddingBottom: Spacing.xl,
    borderBottomLeftRadius: BorderRadius['2xl'], borderBottomRightRadius: BorderRadius['2xl'],
  },
  headerTitle: { fontSize: Typography.sizes['2xl'], fontWeight: Typography.weights.bold, color: '#fff' },
  headerSubtitle: { fontSize: Typography.sizes.sm, color: '#94A3B8', marginTop: 2 },
  stageRow: {
    flexDirection: 'row', paddingHorizontal: Spacing.xl, paddingVertical: Spacing.md,
    gap: Spacing.sm, borderBottomWidth: 1, borderBottomColor: '#E2E8F0',
  },
  stageTab: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    paddingVertical: Spacing.sm, borderRadius: BorderRadius.md, gap: 6,
  },
  stageTabActive: { backgroundColor: BrandColors.secondary + '15' },
  stageTabText: { fontSize: Typography.sizes.sm, color: '#94A3B8', fontWeight: Typography.weights.medium },
  stageTabTextActive: { color: BrandColors.secondary, fontWeight: Typography.weights.bold },
  stageBadge: {
    backgroundColor: '#F1F5F9', paddingHorizontal: 6, paddingVertical: 1, borderRadius: 8,
  },
  stageBadgeActive: { backgroundColor: BrandColors.secondary + '25' },
  stageBadgeText: { fontSize: 10, fontWeight: Typography.weights.bold, color: '#94A3B8' },
  stageBadgeTextActive: { color: BrandColors.secondary },
  scroll: { flex: 1 },
  scrollContent: { padding: Spacing.xl },
  card: { backgroundColor: '#fff', borderRadius: BorderRadius.lg, padding: Spacing.lg, marginBottom: Spacing.md, ...Shadows.sm },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: Spacing.sm },
  cardTitle: { flex: 1, fontSize: Typography.sizes.md, fontWeight: Typography.weights.bold, color: '#1A1A2E', marginRight: Spacing.sm },
  priorityBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: BorderRadius.sm },
  priorityText: { fontSize: 10, fontWeight: Typography.weights.bold, textTransform: 'uppercase' },
  programme: { fontSize: Typography.sizes.sm, color: BrandColors.secondary, fontWeight: Typography.weights.medium, marginBottom: Spacing.sm },
  metaRow: { flexDirection: 'row', gap: Spacing.lg, marginBottom: Spacing.md },
  metaItem: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  metaText: { fontSize: Typography.sizes.xs, color: '#94A3B8' },
  actionRow: { flexDirection: 'row', gap: Spacing.sm, borderTopWidth: 1, borderTopColor: '#F1F5F9', paddingTop: Spacing.md },
  approveButton: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4,
    paddingVertical: Spacing.sm, borderRadius: BorderRadius.md, backgroundColor: BrandColors.successBg,
  },
  approveText: { fontSize: Typography.sizes.sm, fontWeight: Typography.weights.bold, color: BrandColors.success },
  rejectButton: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4,
    paddingVertical: Spacing.sm, paddingHorizontal: Spacing.lg, borderRadius: BorderRadius.md, backgroundColor: BrandColors.errorBg,
  },
  rejectText: { fontSize: Typography.sizes.sm, fontWeight: Typography.weights.bold, color: BrandColors.error },
  emptyState: { alignItems: 'center', paddingVertical: Spacing['3xl'], gap: Spacing.md },
  emptyText: { fontSize: Typography.sizes.md, color: '#94A3B8' },
});
