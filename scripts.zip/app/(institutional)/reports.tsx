/**
 * CampusMind AI - Compliance Reports
 * AI-assisted report generation for governing educational bodies.
 */

import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { BrandColors, BorderRadius, Spacing, Typography, Shadows } from '@/constants/theme';

const REPORT_TEMPLATES = [
  { id: '1', name: 'Annual Programme Monitoring Report', body: 'QAA', icon: 'assessment' as const },
  { id: '2', name: 'Self-Evaluation Document (SED)', body: 'QAA', icon: 'rate-review' as const },
  { id: '3', name: 'ABET Self-Study Report', body: 'ABET', icon: 'school' as const },
  { id: '4', name: 'External Examiner Response', body: 'University', icon: 'reply' as const },
  { id: '5', name: 'Student Satisfaction Action Plan', body: 'NSS', icon: 'feedback' as const },
];

const PAST_REPORTS = [
  { id: '1', name: 'APM Report - Computer Science 2025-26', template: 'Annual Programme Monitoring', date: '2026-07-15', status: 'final', version: 3 },
  { id: '2', name: 'ABET Self-Study Draft', template: 'ABET Self-Study Report', date: '2026-08-10', status: 'draft', version: 1 },
  { id: '3', name: 'NSS Action Plan 2025-26', template: 'Student Satisfaction Action Plan', date: '2026-06-20', status: 'final', version: 2 },
];

export default function ReportsScreen() {
  const [activeTab, setActiveTab] = useState<'generate' | 'history'>('generate');

  const handleGenerate = (template: typeof REPORT_TEMPLATES[0]) => {
    Alert.alert(
      'Generate Report',
      `Generate a "${template.name}" using AI?\n\nThis will create a draft based on your department data and the ${template.body} template.`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Generate', onPress: () => Alert.alert('Coming Soon', 'AI report generation requires an OpenAI API key. Configure it in Settings.') },
      ]
    );
  };

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#1B2A4A', '#0F172A']} style={styles.header}>
        <Text style={styles.headerTitle}>Compliance Reports</Text>
        <Text style={styles.headerSubtitle}>AI-assisted report generation</Text>
      </LinearGradient>

      <View style={styles.tabRow}>
        <TouchableOpacity style={[styles.tab, activeTab === 'generate' && styles.tabActive]} onPress={() => setActiveTab('generate')}>
          <Text style={[styles.tabText, activeTab === 'generate' && styles.tabTextActive]}>Generate New</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.tab, activeTab === 'history' && styles.tabActive]} onPress={() => setActiveTab('history')}>
          <Text style={[styles.tabText, activeTab === 'history' && styles.tabTextActive]}>History</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {activeTab === 'generate' ? (
          <>
            <Text style={styles.sectionTitle}>Report Templates</Text>
            <Text style={styles.sectionSubtitle}>Select a template to generate an AI-drafted compliance report</Text>
            {REPORT_TEMPLATES.map((t) => (
              <TouchableOpacity key={t.id} style={styles.templateCard} onPress={() => handleGenerate(t)} activeOpacity={0.7}>
                <View style={styles.templateIcon}>
                  <MaterialIcons name={t.icon} size={24} color={BrandColors.secondary} />
                </View>
                <View style={styles.templateContent}>
                  <Text style={styles.templateName}>{t.name}</Text>
                  <Text style={styles.templateBody}>{t.body}</Text>
                </View>
                <LinearGradient colors={[BrandColors.secondary, BrandColors.accent]} style={styles.generateChip}>
                  <MaterialIcons name="auto-awesome" size={14} color="#fff" />
                  <Text style={styles.generateChipText}>AI</Text>
                </LinearGradient>
              </TouchableOpacity>
            ))}
          </>
        ) : (
          <>
            <Text style={styles.sectionTitle}>Report History</Text>
            {PAST_REPORTS.map((r) => (
              <TouchableOpacity key={r.id} style={styles.historyCard} activeOpacity={0.7}>
                <View style={styles.historyHeader}>
                  <Text style={styles.historyName}>{r.name}</Text>
                  <View style={[styles.versionBadge, r.status === 'final' ? styles.versionFinal : styles.versionDraft]}>
                    <Text style={[styles.versionText, { color: r.status === 'final' ? BrandColors.success : BrandColors.warning }]}>
                      {r.status === 'final' ? 'Final' : 'Draft'} v{r.version}
                    </Text>
                  </View>
                </View>
                <Text style={styles.historyMeta}>{r.template} • {r.date}</Text>
                <View style={styles.historyActions}>
                  <TouchableOpacity style={styles.actionButton}>
                    <MaterialIcons name="visibility" size={16} color={BrandColors.accent} />
                    <Text style={styles.actionText}>View</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.actionButton}>
                    <MaterialIcons name="download" size={16} color="#64748B" />
                    <Text style={[styles.actionText, { color: '#64748B' }]}>Export PDF</Text>
                  </TouchableOpacity>
                </View>
              </TouchableOpacity>
            ))}
          </>
        )}
        <View style={{ height: Spacing['3xl'] }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  header: {
    paddingTop: 56, paddingHorizontal: Spacing.xl, paddingBottom: Spacing.xl,
    borderBottomLeftRadius: BorderRadius['2xl'], borderBottomRightRadius: BorderRadius['2xl'],
  },
  headerTitle: { fontSize: Typography.sizes['2xl'], fontWeight: Typography.weights.bold, color: '#fff' },
  headerSubtitle: { fontSize: Typography.sizes.sm, color: '#94A3B8', marginTop: 2 },
  tabRow: {
    flexDirection: 'row', paddingHorizontal: Spacing.xl, paddingVertical: Spacing.md,
    gap: Spacing.sm, borderBottomWidth: 1, borderBottomColor: '#E2E8F0',
  },
  tab: { flex: 1, paddingVertical: Spacing.sm, borderRadius: BorderRadius.md, alignItems: 'center' },
  tabActive: { backgroundColor: BrandColors.secondary + '15' },
  tabText: { fontSize: Typography.sizes.md, color: '#94A3B8', fontWeight: Typography.weights.medium },
  tabTextActive: { color: BrandColors.secondary, fontWeight: Typography.weights.bold },
  scroll: { flex: 1 },
  scrollContent: { padding: Spacing.xl },
  sectionTitle: { fontSize: Typography.sizes.lg, fontWeight: Typography.weights.bold, color: '#1A1A2E', marginBottom: 4 },
  sectionSubtitle: { fontSize: Typography.sizes.sm, color: '#64748B', marginBottom: Spacing.lg },
  templateCard: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff',
    borderRadius: BorderRadius.lg, padding: Spacing.base, marginBottom: Spacing.md,
    gap: Spacing.md, ...Shadows.sm,
  },
  templateIcon: {
    width: 48, height: 48, borderRadius: BorderRadius.md, backgroundColor: BrandColors.secondary + '12',
    justifyContent: 'center', alignItems: 'center',
  },
  templateContent: { flex: 1 },
  templateName: { fontSize: Typography.sizes.md, fontWeight: Typography.weights.semibold, color: '#1A1A2E' },
  templateBody: { fontSize: Typography.sizes.xs, color: '#94A3B8', marginTop: 2 },
  generateChip: {
    flexDirection: 'row', alignItems: 'center', gap: 3,
    paddingHorizontal: Spacing.md, paddingVertical: 6, borderRadius: BorderRadius.full,
  },
  generateChipText: { fontSize: 11, fontWeight: Typography.weights.bold, color: '#fff' },
  historyCard: { backgroundColor: '#fff', borderRadius: BorderRadius.lg, padding: Spacing.lg, marginBottom: Spacing.md, ...Shadows.sm },
  historyHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 4 },
  historyName: { flex: 1, fontSize: Typography.sizes.md, fontWeight: Typography.weights.bold, color: '#1A1A2E', marginRight: Spacing.sm },
  versionBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: BorderRadius.sm },
  versionFinal: { backgroundColor: BrandColors.successBg },
  versionDraft: { backgroundColor: BrandColors.warningBg },
  versionText: { fontSize: 10, fontWeight: Typography.weights.bold },
  historyMeta: { fontSize: Typography.sizes.sm, color: '#64748B', marginBottom: Spacing.md },
  historyActions: { flexDirection: 'row', gap: Spacing.md },
  actionButton: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  actionText: { fontSize: Typography.sizes.sm, color: BrandColors.accent, fontWeight: Typography.weights.semibold },
});
