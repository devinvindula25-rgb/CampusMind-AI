/**
 * CampusMind AI - Firestore Document Type Definitions
 * TypeScript interfaces for every Firestore collection document.
 */

// ─── Personal Hub ─────────────────────────────────────────────

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  role: 'lecturer' | 'senior_lecturer' | 'associate_professor' | 'professor' | 'senior_professor';
  department: string;
  institution?: string;
  avatar?: string;
  isSeeded?: boolean; // Flag for auto-seed on first login
  createdAt: string;
  updatedAt: string;
}

export interface ScheduleItem {
  id?: string;
  userId: string;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  title: string;
  type: 'lecture_prep' | 'research_writing' | 'student_consultations' | 'assessment_review' | 'meetings' | 'admin' | 'break';
  isAI?: boolean;
  notes?: string;
  recurring?: 'none' | 'daily' | 'weekly' | 'monthly';
  createdAt: string;
}

export interface Meeting {
  id?: string;
  userId: string;
  title: string;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  type: 'in_person' | 'virtual' | 'hybrid';
  room?: string;
  teamsLink?: string;
  attendees: string[];
  attendeeIds?: string[];
  status: 'scheduled' | 'completed' | 'cancelled';
  notes?: string;
  createdAt: string;
}

export interface Notification {
  id?: string;
  userId: string;
  title: string;
  message: string;
  type: 'compliance' | 'review' | 'ai_recommendation' | 'deadline' | 'system' | 'meeting' | 'research';
  priority: 'urgent' | 'high' | 'medium' | 'low';
  read: boolean;
  actionUrl?: string;
  createdAt: string;
}

export interface ResearchProject {
  id?: string;
  userId: string;
  title: string;
  status: 'proposed' | 'active' | 'completed' | 'paused';
  publications: number;
  conferences: number;
  grant?: { title: string; amount: string; status: 'applied' | 'awarded' | 'rejected' };
  ethics: 'not_submitted' | 'submitted' | 'approved' | 'rejected';
  predictedDelay: number | null;
  progress: number; // 0-100
  deadline: string;
  description?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Publication {
  id?: string;
  userId: string;
  projectId?: string;
  title: string;
  journal: string;
  year: number;
  status: 'draft' | 'submitted' | 'under_review' | 'accepted' | 'published' | 'rejected';
  doi?: string;
  coAuthors?: string[];
  createdAt: string;
}

export interface WellnessLog {
  id?: string;
  userId: string;
  date: string; // YYYY-MM-DD
  stressLevel: number; // 1-5
  workingHours?: number;
  meetingsCount?: number;
  sleepHours?: number;
  waterIntakeMl?: number;
  exerciseMinutes?: number;
  mood?: 'great' | 'good' | 'okay' | 'poor' | 'terrible';
  notes?: string;
  createdAt: string;
}

export interface EmailDraft {
  id?: string;
  userId: string;
  subject: string;
  body: string;
  recipient?: string;
  context?: 'student_inquiry' | 'extension_request' | 'supervisor' | 'committee';
  status: 'draft' | 'sent' | 'archived';
  createdAt: string;
}

// ─── Institutional Hub ────────────────────────────────────────

export interface AccreditationRecord {
  id?: string;
  departmentId: string;
  programmeName: string;
  accreditingBody: string;
  status: 'active' | 'expiring_soon' | 'expired' | 'under_review';
  expiryDate: string;
  lastReviewDate?: string;
  complianceScore?: number;
  standards?: { code: string; title: string; status: string; evidence?: string }[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface CurriculumReview {
  id?: string;
  departmentId: string;
  programmeName: string;
  reviewType: 'annual' | 'periodic' | 'ad_hoc';
  status: 'pending' | 'in_progress' | 'completed' | 'overdue';
  dueDate: string;
  reviewer?: string;
  findings?: string;
  recommendations?: string[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuditRecord {
  id?: string;
  departmentId: string;
  auditTitle: string;
  auditType: 'internal' | 'external' | 'regulatory';
  status: 'scheduled' | 'in_progress' | 'completed' | 'follow_up_required';
  date: string;
  auditor?: string;
  findings?: string;
  nonConformities?: number;
  actionItems?: { description: string; assignee: string; dueDate: string; status: string }[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface ComplianceReport {
  id?: string;
  departmentId: string;
  title: string;
  reportType: 'quarterly' | 'annual' | 'ad_hoc' | 'regulatory';
  status: 'draft' | 'submitted' | 'approved' | 'rejected';
  period: string;
  summary?: string;
  complianceScore?: number;
  sections?: { title: string; status: string; score: number; notes?: string }[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface QADocument {
  id?: string;
  departmentId: string;
  title: string;
  category: 'policy' | 'procedure' | 'template' | 'evidence' | 'report';
  version: string;
  status: 'draft' | 'active' | 'archived' | 'under_review';
  fileUrl?: string;
  fileSize?: string;
  tags?: string[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}
